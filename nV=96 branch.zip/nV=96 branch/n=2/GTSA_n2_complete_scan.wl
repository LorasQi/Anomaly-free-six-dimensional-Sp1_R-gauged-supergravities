(* ::Package:: *)
(*
  GTSA_n2_complete_scan_NEW_CONVENTION_20260715.wl

  Complete n = 2 GTSA scan for the n_V = 96 Sp(1)_R branch.

  Inputs, by default:
    C:\Physics\6d anomaly free models\n=2\RepInfo.nb
    C:\Physics\6d anomaly free models\n=2\n1_Sp1R_Catalogue.pdf

  Main points implemented:
    - all compatible unordered gauge-group pairs from the final n = 1 catalogue;
    - optional reverse scan order for the gauge-group-pair list;
    - half-integer multiplicities only when the final product representation is pseudoreal;
    - PS == 1/2 is treated as pseudoreal; PS == 1 is split into real/complex by Dynkin conjugation;
    - local anomaly check is repeated for every final spectrum, including MatrixRank[M] <= 2;
    - identical-factor permutation duplicates are removed by a canonical spectrum key;
    - each pair writes only one readable .txt file in pair_outputs after the pair finishes;
    - final full list is written at the end.
*)

ClearAll["Global`*"];

(* ---------------------------------------------------------------------- *)
(* User settings                                                          *)
(* ---------------------------------------------------------------------- *)

(* Version marker: progress settings included, 2026-07-03. *)
$GTSAN2CompleteScanVersion = "new-offdiag-convention-n1-parser-v1-20260715";

(* These are defaults. If you set any of these variables in your notebook
   before Get["GTSA_n2_complete_scan.wl"], your notebook value is kept. *)
If[! ValueQ[$BaseDir], $BaseDir = "C:\\Physics\\6d anomaly free models\\n=2"];
If[! ValueQ[$RepInfoFile], $RepInfoFile = FileNameJoin[{$BaseDir, "RepInfo.nb"}]];
If[! ValueQ[$N1CataloguePDF], $N1CataloguePDF = FileNameJoin[{$BaseDir, "n1_Sp1R_Catalogue.pdf"}]];

If[! ValueQ[$ReverseGroupPairOrder], $ReverseGroupPairOrder = False];
If[! ValueQ[$RequireIntegralAnomalyVectors], $RequireIntegralAnomalyVectors = True];
If[! ValueQ[$RequireNonnegativeDroneCount], $RequireNonnegativeDroneCount = True];
If[! ValueQ[$TreatEqualGroupFactorsAsOrdered], $TreatEqualGroupFactorsAsOrdered = True];

(* If True, spectra related by exchanging two identical simple factors, e.g. A3 x A3,
   are represented only once in pair outputs and in the final total. *)
If[! ValueQ[$QuotientIdenticalFactorPermutation], $QuotientIdenticalFactorPermutation = True];

(* If True, old non-readable pair artifacts from earlier runs are removed from pair_outputs.
   This deletes *.wl, *.wxf and *_count.txt inside pair_outputs, but keeps ordinary *.txt spectra files. *)
If[! ValueQ[$CleanPairOutputFolderToTextOnly], $CleanPairOutputFolderToTextOnly = True];

(* If True, group pairs with negative drone count are removed before scanning.
   For future n = 3 scans, the analogous rule is Total[dim Gi] <= 93. *)
If[! ValueQ[$PruneNegativeDronePairsAtStart], $PruneNegativeDronePairsAtStart = True];

(* If True, temporary checkpoint files are deleted after a successful full scan.
   Final files such as n2_GTSA_all_spectra.wl, n2_GTSA_all_spectra.wxf,
   n2_GTSA_all_spectra_readable.txt, and n2_GTSA_pair_counts_final.csv are kept. *)
If[! ValueQ[$DeleteTemporaryFilesAfterFullScan], $DeleteTemporaryFilesAfterFullScan = True];

If[! ValueQ[$RunNow], $RunNow = True];

(* Print progress within each gauge-group pair scan.
   With $PairScanProgressEvery = 1000 this prints 1/N, 1001/N, 2001/N, ..., and N/N. *)
If[! ValueQ[$PrintPairScanProgress], $PrintPairScanProgress = True];
If[! ValueQ[$PairScanProgressEvery], $PairScanProgressEvery = 1000];

If[! ValueQ[$OutDir], $OutDir = FileNameJoin[{$BaseDir, "n2_GTSA_complete_outputs"}]];
If[! ValueQ[$PairOutDir], $PairOutDir = FileNameJoin[{$OutDir, "pair_outputs"}]];

$nV = 96;
$nH = $nV + 244;
$dimNonRMax = $nV - 3;

(* Off-diagonal coordinate convention used in the revised n_V=96 catalogues. *)
$aVec = {-2, -2};
$bRVec = {3/2, -5};

(* ---------------------------------------------------------------------- *)
(* General utilities                                                      *)
(* ---------------------------------------------------------------------- *)

etaDot[u_List, v_List] := u[[1]] v[[2]] + u[[2]] v[[1]];
etaNorm[u_List] := etaDot[u, u];
innerRow[u_List] := {u[[2]], u[[1]]};

(* In these displayed off-diagonal coordinates, the integral odd I_{1,1}
   lattice is the image of Z^2 under (m,n) -> ((m+n)/2,m-n). *)
latticeAdmissibleQ[v_List] := Module[{twox = Together[2 v[[1]]], y = Together[v[[2]]]},
  IntegerQ[twox] && IntegerQ[y] && EvenQ[twox - y]
];

safeName[s_String] := StringReplace[s, Except[WordCharacter] -> "_"];
vecString[v_List] := "(" <> StringRiffle[ToString /@ v, ","] <> ")";
vecKey[v_List] := ToString[InputForm[v]];
fromVecKey[k_String] := ToExpression[k];

intQ[x_] := TrueQ[IntegerQ[x]];
nonnegQ[x_] := TrueQ[x >= 0];

ratRange[max_, step_] := Table[i step, {i, 0, Floor[max/step]}];

formatRational[x_] := Which[
  IntegerQ[x], ToString[x],
  Denominator[x] == 2 && Numerator[x] == 1, "1/2",
  Denominator[x] == 2, ToString[Numerator[x]] <> "/2",
  True, ToString[InputForm[x]]
];

formatMult[x_] := If[x === 1, "", formatRational[x] <> " x "];

(* ---------------------------------------------------------------------- *)
(* Lie-group conventions                                                  *)
(* ---------------------------------------------------------------------- *)

groupType[g_String] := StringTake[g, 1];
groupRank[g_String] := ToExpression[StringDrop[g, 1]];

lambdaFactor[g_String] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", 1,
    "B", 2,
    "C", 1,
    "D", 2,
    "E", Switch[n, 6, 6, 7, 12, 8, 60, _, Missing["UnknownLambda", g]],
    "F", 6,
    "G", 2,
    _, Missing["UnknownLambda", g]
  ]
];

normalizeGroupName[Subscript[s_, n_Integer]] := ToUpperCase[StringTake[SymbolName[Unevaluated[s]], 1]] <> ToString[n];
normalizeGroupName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {
    "Subscript[a, " ~~ n : DigitCharacter.. ~~ "]" :> "A" <> n,
    "Subscript[b, " ~~ n : DigitCharacter.. ~~ "]" :> "B" <> n,
    "Subscript[c, " ~~ n : DigitCharacter.. ~~ "]" :> "C" <> n,
    "Subscript[d, " ~~ n : DigitCharacter.. ~~ "]" :> "D" <> n,
    "Subscript[e, " ~~ n : DigitCharacter.. ~~ "]" :> "E" <> n,
    "Subscript[f, " ~~ n : DigitCharacter.. ~~ "]" :> "F" <> n,
    "Subscript[g, " ~~ n : DigitCharacter.. ~~ "]" :> "G" <> n
  }]
];

normalizeRepName[Subscript[r_, n_Integer]] := "r" <> ToString[n];
normalizeRepName[s_Symbol] := SymbolName[Unevaluated[s]];
normalizeRepName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {"Subscript[r, " ~~ n : DigitCharacter.. ~~ "]" :> "r" <> n}]
];

(* Dynkin-label conjugation.  PS == 1 is not enough: A_n, D_odd and E6 can be complex. *)
conjugateDynkin[g_String, dyn_List] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", Reverse[dyn],
    "D", If[OddQ[n], ReplacePart[dyn, {n - 1 -> dyn[[n]], n -> dyn[[n - 1]]}], dyn],
    "E", If[n == 6, dyn[[{5, 4, 3, 2, 1, 6}]], dyn],
    _, dyn
  ]
];

realityType[g_String, ps_, dyn_List] := Which[
  ps === 1/2, "Pseudoreal",
  ps === Rational[1, 2], "Pseudoreal",
  conjugateDynkin[g, dyn] === dyn, "Real",
  True, "Complex"
];

productPseudoRealQ[r1_Association, r2_Association] := Sort[{r1["Reality"], r2["Reality"]}] === {"Pseudoreal", "Real"};

allowedMultiplicityQ[m_, r_Association] := IntegerQ[m] || (r["Reality"] === "Pseudoreal" && IntegerQ[2 m]);
allowedProductMultiplicityQ[m_, r1_Association, r2_Association] := IntegerQ[m] || (productPseudoRealQ[r1, r2] && IntegerQ[2 m]);

(* ---------------------------------------------------------------------- *)
(* Load and normalize RepInfo.nb                                          *)
(* ---------------------------------------------------------------------- *)

loadNotebookInputs[file_] := Module[{inputs, ok = False},
  Clear[reps];
  inputs = Quiet @ Check[NotebookImport[file, "Input"], $Failed];
  If[inputs === $Failed,
    inputs = Quiet @ Check[NotebookImport[file, "InputText"], $Failed]
  ];
  If[inputs === $Failed,
    Print["Could not import input cells from ", file]; Abort[]
  ];
  Scan[
    Function[expr,
      Quiet @ Check[ReleaseHold[expr]; ok = True, Null];
      If[! ValueQ[reps], Quiet @ Check[ToExpression[ToString[Unevaluated[expr], InputForm]]; ok = True, Null]];
      If[StringQ[expr] && ! ValueQ[reps], Quiet @ Check[ToExpression[expr]; ok = True, Null]];
    ],
    Flatten[{inputs}]
  ];
  If[! ValueQ[reps], Print["The symbol reps was not defined after reading ", file]; Abort[]];
  reps
];

buildRepData[repRules_] := Association @ Map[
  Function[grule,
    Module[{g, raw, repAssoc},
      g = normalizeGroupName[grule[[1]]];
      raw = grule[[2]];
      repAssoc = Association @ MapIndexed[
        Function[{rr, idx},
          Module[{nm, coeffs, dyn, dimv, ps, assoc},
            nm = normalizeRepName[rr[[1]]];
            coeffs = Association[rr[[2]]];
            dyn = Lookup[coeffs, dynkin];
            dimv = Lookup[coeffs, dim];
            ps = Lookup[coeffs, PS];
            assoc = <|
              "Name" -> nm,
              "Index" -> idx[[1]],
              "Dynkin" -> dyn,
              "Dim" -> dimv,
              "PS" -> ps,
              "Reality" -> realityType[g, ps, dyn],
              "QuarticB" -> Lookup[coeffs, Global`a],
              "QuadC" -> Lookup[coeffs, Global`b],
              "IndexA" -> Lookup[coeffs, Global`c],
              "ExtraD" -> Lookup[coeffs, Global`d]
            |>;
            nm -> assoc
          ]
        ],
        raw
      ];
      g -> <|
        "Group" -> g,
        "Rank" -> groupRank[g],
        "Lambda" -> lambdaFactor[g],
        "Reps" -> repAssoc,
        "DimG" -> repAssoc["adj"]["Dim"]
      |>
    ]
  ],
  repRules
];

loadRepData[file_] := buildRepData[loadNotebookInputs[file]];

(* ---------------------------------------------------------------------- *)
(* Parse the final n = 1 PDF catalogue                                    *)
(* ---------------------------------------------------------------------- *)

findRepByDynkinDim[repData_, g_String, dyn_List, dimv_Integer] := Module[{lst, hit},
  lst = Values[repData[g]["Reps"]];
  hit = Select[lst, (#["Dynkin"] === dyn && #["Dim"] === dimv) &];
  If[Length[hit] != 1,
    Print["Could not uniquely match representation in ", g, ": dynkin=", dyn, ", dim=", dimv, "; matches=", Length[hit]];
    Abort[]
  ];
  First[hit]
];

parseSpectrumTerms[spec_String, g_String, repData_] := Module[{termRE, rawTerms},
  termRE = RegularExpression["(\\d+)\\s*x\\s*\\(([^\\)]*)\\)\\s*(\\d+)\\s*(half)?"];
  rawTerms = StringCases[spec, termRE -> {"$1", "$2", "$3", "$4"}];
  Map[
    Function[t,
      Module[{m0, dyn, dimv, half, rep, mult},
        m0 = ToExpression[t[[1]]];
        dyn = ToExpression["{" <> StringReplace[t[[2]], WhitespaceCharacter .. -> ""] <> "}"];
        dimv = ToExpression[t[[3]]];
        half = StringTrim[t[[4]]] === "half";
        rep = findRepByDynkinDim[repData, g, dyn, dimv];
        mult = If[half, m0/2, m0];
        If[! allowedMultiplicityQ[mult, rep],
          Print["Bad one-factor multiplicity in PDF for ", g, ": ", mult, " x ", rep["Name"], " has reality ", rep["Reality"]];
          Abort[]
        ];
        <|"Rep" -> rep["Name"], "Mult" -> mult|>
      ]
    ],
    rawTerms
  ]
];

spectrumSumsOneFactor[sp_Association, repData_] := Module[{g = sp["Group"], reps, entries},
  reps = repData[g]["Reps"];
  entries = sp["Entries"];
  <|
    "IndexA" -> Total[(#["Mult"] reps[#["Rep"]]["IndexA"]) & /@ entries],
    "QuadC" -> Total[(#["Mult"] reps[#["Rep"]]["QuadC"]) & /@ entries],
    "QuarticB" -> Total[(#["Mult"] reps[#["Rep"]]["QuarticB"]) & /@ entries],
    "ExtraD" -> Total[(#["Mult"] reps[#["Rep"]]["ExtraD"]) & /@ entries]
  |>
];

deriveBranchVector[sp_Association, repData_] := Module[
  {g = sp["Group"], lam, adj, sums, dotA, dotR, mat, vec, normReq, checks},
  lam = repData[g]["Lambda"];
  adj = repData[g]["Reps"]["adj"];
  sums = spectrumSumsOneFactor[sp, repData];
  dotA = lam/6 (adj["IndexA"] - sums["IndexA"]);
  dotR = -lam adj["IndexA"]/2;
  mat = {innerRow[$aVec], innerRow[$bRVec]};
  vec = Together[LinearSolve[mat, {dotA, dotR}]];
  normReq = lam^2/3 (sums["QuadC"] - adj["QuadC"]);
  checks = <|
    "aDot" -> dotA,
    "bRDot" -> dotR,
    "normRequired" -> Together[normReq],
    "normActual" -> Together[etaNorm[vec]],
    "quarticBResidual" -> Together[adj["QuarticB"] - sums["QuarticB"]],
    "extraDResidual" -> Together[adj["ExtraD"] - sums["ExtraD"]]
  |>;
  {vec, checks}
];

parseN1Catalogue[pdfFile_, repData_] := Module[
  {txt, clean, groups, headers, blocks, rowRE, spectra},
  txt = Import[pdfFile, "Plaintext"];
  clean = StringReplace[txt, {"\r" -> " ", "\n" -> " ", WhitespaceCharacter .. -> " "}];
  groups = Keys[repData];
  headers = SortBy[
    Flatten[
      Table[(Append[#, g] & /@ StringPosition[clean, g <> " spectra"]), {g, groups}],
      1
    ],
    First
  ];
  headers = DeleteDuplicatesBy[headers, {#[[1]], #[[3]]} &];
  blocks = Table[
    Module[{start = headers[[i, 2]] + 1, stop, g = headers[[i, 3]]},
      stop = If[i < Length[headers], headers[[i + 1, 1]] - 1, StringLength[clean]];
      {g, StringTake[clean, {start, stop}]}
    ],
    {i, Length[headers]}
  ];

  (* Revised n=1 rows have the form
       ID  (b_x,b_y)  singlets  H_charged  charged spectrum.
     The branch displayed in the PDF is checked against an independent
     recomputation from RepInfo.nb. *)
  rowRE = RegularExpression[
    "(\\d+)\\s+\\(\\s*(-?\\d+(?:/\\d+)?)\\s*,\\s*(-?\\d+(?:/\\d+)?)\\s*\\)\\s+" <>
    "(\\d+)\\s+(\\d+)\\s+(.*?)(?=(?:\\s\\d+\\s+\\(\\s*-?\\d+(?:/\\d+)?\\s*,\\s*-?\\d+(?:/\\d+)?\\s*\\)\\s+\\d+\\s+\\d+\\s+)|$)"
  ];
  spectra = Flatten[
    Map[
      Function[blk,
        Module[{g = blk[[1]], block = blk[[2]], rows},
          rows = StringCases[block, rowRE -> {"$1", "$2", "$3", "$4", "$5", "$6"}];
          Map[
            Function[r,
              Module[{sp, br, shownBr, checks},
                shownBr = ToExpression /@ r[[{2, 3}]];
                sp = <|
                  "ID" -> ToExpression[r[[1]]],
                  "Group" -> g,
                  "Singlets" -> ToExpression[r[[4]]],
                  "HCharged" -> ToExpression[r[[5]]],
                  "Entries" -> parseSpectrumTerms[r[[6]], g, repData]
                |>;
                {br, checks} = deriveBranchVector[sp, repData];
                If[br =!= shownBr,
                  Print["Displayed/recomputed branch mismatch for n=1 ID ", sp["ID"],
                    ": displayed=", shownBr, ", recomputed=", br];
                  Abort[]
                ];
                Join[sp, <|"Branch" -> br, "OneFactorChecks" -> checks|>]
              ]
            ],
            rows
          ]
        ]
      ],
      blocks
    ],
    1
  ];
  Print["Parsed ", Length[spectra], " one-factor spectra from ", pdfFile];
  spectra
];

(* ---------------------------------------------------------------------- *)
(* Pair assembly                                                           *)
(* ---------------------------------------------------------------------- *)

repAssocFromEntries[entries_List] := Merge[(#["Rep"] -> #["Mult"]) & /@ entries, Total];
positiveAssoc[a_Association] := Association @ KeyValueMap[If[#2 === 0, Nothing, #1 -> #2] &, a];

subtractAssoc[a_Association, key_, amount_] := Module[{b = a, val},
  val = Lookup[b, key, 0] - amount;
  If[val < 0, Return[$Failed]];
  If[val === 0, KeyDropFrom[b, key], b[key] = val];
  b
];

allowedLeftoversQ[rem_Association, reps_Association] := AllTrue[Normal[rem], allowedMultiplicityQ[#[[2]], reps[#[[1]]]] &];

buildEntriesFromState[g1_, g2_, rem1_, rem2_, links_, repData_] := Module[{entries1, entries2, entriesLinks},
  entries1 = KeyValueMap[<|"Rep1" -> #1, "Rep2" -> "r0", "Mult" -> #2|> &, rem1];
  entries2 = KeyValueMap[<|"Rep1" -> "r0", "Rep2" -> #1, "Mult" -> #2|> &, rem2];
  entriesLinks = Map[<|"Rep1" -> #[[1]], "Rep2" -> #[[2]], "Mult" -> #[[3]]|> &, links];
  Select[Join[entriesLinks, entries1, entries2], #["Mult"] =!= 0 &]
];

chargedHDim[entries_List, g1_, g2_, repData_] := Module[{reps1 = repData[g1]["Reps"], reps2 = repData[g2]["Reps"]},
  Total[(#["Mult"] reps1[#["Rep1"]]["Dim"] reps2[#["Rep2"]]["Dim"]) & /@ entries]
];

formatRepShort[g_, rep_, repData_] := Module[{r = repData[g]["Reps"][rep]},
  If[rep === "r0", "1",
    "(" <> StringRiffle[ToString /@ r["Dynkin"], ","] <> ")_" <> ToString[r["Dim"]]
  ]
];

formatEntry[e_, g1_, g2_, repData_] := formatMult[e["Mult"]] <> "(" <> formatRepShort[g1, e["Rep1"], repData] <> "," <> formatRepShort[g2, e["Rep2"], repData] <> ")";

formatSpectrum[sol_, repData_] := Module[{terms},
  terms = Join[
    {formatMult[sol["Singlets"]] <> "(1,1)"},
    formatEntry[#, sol["Group1"], sol["Group2"], repData] & /@ sol["Entries"]
  ];
  StringRiffle[Select[terms, StringLength[#] > 0 &], " + "]
];

entryKeyList[entries_List] := Sort[({#["Rep1"], #["Rep2"], #["Mult"]} & /@ entries)];

swapEntry[e_Association] := <|"Rep1" -> e["Rep2"], "Rep2" -> e["Rep1"], "Mult" -> e["Mult"]|>;

orderedSolutionKeyData[sol_Association] := {
  sol["Group1"], sol["Group2"], sol["Branch1"], sol["Branch2"], sol["Singlets"], entryKeyList[sol["Entries"]]
};

swappedSolutionKeyData[sol_Association] := {
  sol["Group2"], sol["Group1"], sol["Branch2"], sol["Branch1"], sol["Singlets"], entryKeyList[swapEntry /@ sol["Entries"]]
};

(* Canonical key used for de-duplication.  For identical factors this quotients by
   the exchange symmetry G1 <-> G2, so spectra such as 3 and 10 in A3 x A3 are counted once. *)
solutionKey[sol_Association] := Module[{k1, k2},
  k1 = orderedSolutionKeyData[sol];
  If[TrueQ[$QuotientIdenticalFactorPermutation] && sol["Group1"] === sol["Group2"],
    k2 = swappedSolutionKeyData[sol];
    ToString[InputForm[First[Sort[{k1, k2}]]]],
    ToString[InputForm[k1]]
  ]
];

localAnomalyMatrixAndCheck[entries_List, singlets_, g1_, g2_, b1_, b2_, repData_] := Module[
  {reps1, reps2, lam1, lam2, adj1, adj2, sums1, sums2, mixed, coeffRF1, coeffRF2,
   coeffF1F1, coeffF2F2, coeffF1F2, mat, rank, quartic1, quartic2, dres1, dres2},
  reps1 = repData[g1]["Reps"]; reps2 = repData[g2]["Reps"];
  lam1 = repData[g1]["Lambda"]; lam2 = repData[g2]["Lambda"];
  adj1 = reps1["adj"]; adj2 = reps2["adj"];
  sums1 = <|
    "IndexA" -> Total[(#["Mult"] reps2[#["Rep2"]]["Dim"] reps1[#["Rep1"]]["IndexA"]) & /@ Select[entries, #["Rep1"] =!= "r0" &]],
    "QuadC" -> Total[(#["Mult"] reps2[#["Rep2"]]["Dim"] reps1[#["Rep1"]]["QuadC"]) & /@ Select[entries, #["Rep1"] =!= "r0" &]],
    "QuarticB" -> Total[(#["Mult"] reps2[#["Rep2"]]["Dim"] reps1[#["Rep1"]]["QuarticB"]) & /@ Select[entries, #["Rep1"] =!= "r0" &]],
    "ExtraD" -> Total[(#["Mult"] reps2[#["Rep2"]]["Dim"] reps1[#["Rep1"]]["ExtraD"]) & /@ Select[entries, #["Rep1"] =!= "r0" &]]
  |>;
  sums2 = <|
    "IndexA" -> Total[(#["Mult"] reps1[#["Rep1"]]["Dim"] reps2[#["Rep2"]]["IndexA"]) & /@ Select[entries, #["Rep2"] =!= "r0" &]],
    "QuadC" -> Total[(#["Mult"] reps1[#["Rep1"]]["Dim"] reps2[#["Rep2"]]["QuadC"]) & /@ Select[entries, #["Rep2"] =!= "r0" &]],
    "QuarticB" -> Total[(#["Mult"] reps1[#["Rep1"]]["Dim"] reps2[#["Rep2"]]["QuarticB"]) & /@ Select[entries, #["Rep2"] =!= "r0" &]],
    "ExtraD" -> Total[(#["Mult"] reps1[#["Rep1"]]["Dim"] reps2[#["Rep2"]]["ExtraD"]) & /@ Select[entries, #["Rep2"] =!= "r0" &]]
  |>;
  mixed = Total[(#["Mult"] reps1[#["Rep1"]]["IndexA"] reps2[#["Rep2"]]["IndexA"]) & /@ Select[entries, #["Rep1"] =!= "r0" && #["Rep2"] =!= "r0" &]];
  quartic1 = Together[adj1["QuarticB"] - sums1["QuarticB"]];
  quartic2 = Together[adj2["QuarticB"] - sums2["QuarticB"]];
  dres1 = Together[adj1["ExtraD"] - sums1["ExtraD"]];
  dres2 = Together[adj2["ExtraD"] - sums2["ExtraD"]];
  coeffRF1 = 1/6 (adj1["IndexA"] - sums1["IndexA"]);
  coeffRF2 = 1/6 (adj2["IndexA"] - sums2["IndexA"]);
  coeffF1F1 = 2/3 (sums1["QuadC"] - adj1["QuadC"]);
  coeffF2F2 = 2/3 (sums2["QuadC"] - adj2["QuadC"]);
  coeffF1F2 = 4 mixed;
  mat = Together[{
    {1, ($nV - 12)/24, coeffRF1/2, coeffRF2/2},
    {($nV - 12)/24, -($nV + 84)/6, -adj1["IndexA"], -adj2["IndexA"]},
    {coeffRF1/2, -adj1["IndexA"], coeffF1F1, coeffF1F2/2},
    {coeffRF2/2, -adj2["IndexA"], coeffF1F2/2, coeffF2F2}
  }];
  rank = MatrixRank[mat];
  <|
    "Pass" -> (quartic1 === 0 && quartic2 === 0 && dres1 === 0 && dres2 === 0 && rank <= 2),
    "Rank" -> rank,
    "Matrix" -> mat,
    "QuarticResiduals" -> {quartic1, quartic2},
    "DResiduals" -> {dres1, dres2},
    "MixedA1A2" -> Together[mixed],
    "ExpectedMixedA1A2" -> Together[etaDot[b1, b2]/(lam1 lam2)]
  |>
];

assembleFromTwoSpectra[g1_, g2_, b1_, b2_, sp1_, sp2_, repData_] := Module[
  {reps1, reps2, lam1, lam2, target, rem1, rem2, keys1, keys2, edges, edgeData, solutions = {}, recurse},
  reps1 = repData[g1]["Reps"]; reps2 = repData[g2]["Reps"];
  lam1 = repData[g1]["Lambda"]; lam2 = repData[g2]["Lambda"];
  target = Together[etaDot[b1, b2]/(lam1 lam2)];
  If[target < 0, Return[{}]];
  rem1 = positiveAssoc @ KeyDrop[repAssocFromEntries[sp1["Entries"]], "r0"];
  rem2 = positiveAssoc @ KeyDrop[repAssocFromEntries[sp2["Entries"]], "r0"];
  keys1 = Keys[rem1]; keys2 = Keys[rem2];
  edges = Select[Tuples[{keys1, keys2}], reps1[#[[1]]]["IndexA"] reps2[#[[2]]]["IndexA"] > 0 &];
  edgeData = SortBy[
    Map[
      Function[e,
        Module[{r1 = reps1[e[[1]]], r2 = reps2[e[[2]]]},
          <|
            "Rep1" -> e[[1]], "Rep2" -> e[[2]],
            "Dim1" -> r1["Dim"], "Dim2" -> r2["Dim"],
            "Contrib" -> Together[r1["IndexA"] r2["IndexA"]],
            "Step" -> If[productPseudoRealQ[r1, r2], 1/2, 1]
          |>
        ]
      ],
      edges
    ],
    -#["Contrib"] &
  ];
  recurse[i_, remTarget_, cur1_, cur2_, links_] := Module[{ed, max, vals, r1, r2, new1, new2, entries, hdim, sing, check, sol},
    If[remTarget < 0, Return[Null]];
    If[remTarget === 0,
      If[! allowedLeftoversQ[cur1, reps1] || ! allowedLeftoversQ[cur2, reps2], Return[Null]];
      entries = buildEntriesFromState[g1, g2, cur1, cur2, links, repData];
      If[! AllTrue[entries, allowedProductMultiplicityQ[#["Mult"], reps1[#["Rep1"]], reps2[#["Rep2"]]] &], Return[Null]];
      hdim = chargedHDim[entries, g1, g2, repData];
      sing = Together[$nH - hdim];
      If[sing < 0 || ! IntegerQ[sing], Return[Null]];
      check = localAnomalyMatrixAndCheck[entries, sing, g1, g2, b1, b2, repData];
      If[! TrueQ[check["Pass"]], Return[Null]];
      sol = <|
        "Group1" -> g1, "Group2" -> g2,
        "Branch1" -> b1, "Branch2" -> b2,
        "N1ID1" -> sp1["ID"], "N1ID2" -> sp2["ID"],
        "Singlets" -> sing,
        "Entries" -> SortBy[entries, {#["Rep1"] &, #["Rep2"] &, #["Mult"] &}],
        "LocalCheck" -> check
      |>;
      AppendTo[solutions, sol];
      Return[Null]
    ];
    If[i > Length[edgeData], Return[Null]];
    ed = edgeData[[i]];
    r1 = reps1[ed["Rep1"]]; r2 = reps2[ed["Rep2"]];
    max = Min[
      Lookup[cur1, ed["Rep1"], 0]/ed["Dim2"],
      Lookup[cur2, ed["Rep2"], 0]/ed["Dim1"],
      remTarget/ed["Contrib"]
    ];
    vals = ratRange[max, ed["Step"]];
    Scan[
      Function[x,
        If[! allowedProductMultiplicityQ[x, r1, r2], Return[Null]];
        new1 = subtractAssoc[cur1, ed["Rep1"], ed["Dim2"] x];
        If[new1 === $Failed, Return[Null]];
        new2 = subtractAssoc[cur2, ed["Rep2"], ed["Dim1"] x];
        If[new2 === $Failed, Return[Null]];
        recurse[i + 1, Together[remTarget - ed["Contrib"] x], new1, new2,
          If[x === 0, links, Append[links, {ed["Rep1"], ed["Rep2"], x}]]]
      ],
      vals
    ];
  ];
  recurse[1, target, rem1, rem2, {}];
  DeleteDuplicatesBy[solutions, solutionKey]
];

(* ---------------------------------------------------------------------- *)
(* Output                                                                 *)
(* ---------------------------------------------------------------------- *)

writePairOutput[pairTag_, sols_, repData_] := Module[{txtFile, readable},
  If[! DirectoryQ[$PairOutDir], CreateDirectory[$PairOutDir, CreateIntermediateDirectories -> True]];
  txtFile = FileNameJoin[{$PairOutDir, pairTag <> ".txt"}];
  readable = If[Length[sols] == 0,
    "No spectra.",
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum[#1, repData] &, sols], "\n"]
  ];
  Export[txtFile, readable, "Text"];
];

appendCountCSV[row_Association, csvFile_] := Module[{header, line},
  header = "pair_index,group1,group2,dimG1,dimG2,M_drone,count\n";
  If[! FileExistsQ[csvFile], Export[csvFile, header, "Text"]];
  line = StringRiffle[ToString /@ Lookup[row, {"pair_index", "group1", "group2", "dimG1", "dimG2", "M_drone", "count"}], ","] <> "\n";
  WriteString[csvFile, line]
];

(* ---------------------------------------------------------------------- *)
(* Driver                                                                 *)
(* ---------------------------------------------------------------------- *)

allGroupPairs[groups_List] := Module[{pairs},
  pairs = Flatten[Table[{groups[[i]], groups[[j]]}, {i, Length[groups]}, {j, i, Length[groups]}], 1];
  If[$ReverseGroupPairOrder, Reverse[pairs], pairs]
];

droneCountForGroupList[groupList_List, repData_] := $dimNonRMax - Total[(repData[#]["DimG"] &) /@ groupList];

pruneNegativeDroneGroupLists[groupLists_List, repData_] := Module[{kept, deleted},
  If[! TrueQ[$PruneNegativeDronePairsAtStart], Return[groupLists]];
  kept = Select[groupLists, droneCountForGroupList[#, repData] >= 0 &];
  deleted = Length[groupLists] - Length[kept];
  If[deleted > 0,
    Print["Pruned ", deleted, " gauge-sector entries with negative drone count before scanning."]
  ];
  kept
];

scanOneGroupPair[pairIndex_, g1_, g2_, n1ByGB_, repData_] := Module[
  {dim1, dim2, mDrone, branches1, branches2, branchPairs, activeBranchPairs,
   totalSpectrumPairs, spectrumPairCounter = 0, sols = {}, pairTag, printProgressQ,
   countOneBP, currentList1, currentList2, partial, t0},
  dim1 = repData[g1]["DimG"]; dim2 = repData[g2]["DimG"];
  mDrone = $dimNonRMax - dim1 - dim2;
  pairTag = StringPadLeft[ToString[pairIndex], 3, "0"] <> "_" <> g1 <> "x" <> g2;
  Print["\nScanning pair ", pairIndex, ": ", g1, " x ", g2, "   M_drone = ", mDrone];
  If[$RequireNonnegativeDroneCount && mDrone < 0,
    Print["  skipped: negative drone count."];
    writePairOutput[pairTag, {}, repData];
    Return[<|"pair_index" -> pairIndex, "group1" -> g1, "group2" -> g2, "dimG1" -> dim1, "dimG2" -> dim2, "M_drone" -> mDrone, "count" -> 0|>]
  ];
  If[! KeyExistsQ[n1ByGB, g1] || ! KeyExistsQ[n1ByGB, g2],
    Print["  skipped: missing one-factor data."];
    writePairOutput[pairTag, {}, repData];
    Return[<|"pair_index" -> pairIndex, "group1" -> g1, "group2" -> g2, "dimG1" -> dim1, "dimG2" -> dim2, "M_drone" -> mDrone, "count" -> 0|>]
  ];

  Print["  preparing branch-pair list..."];
  branches1 = Keys[n1ByGB[g1]];
  branches2 = Keys[n1ByGB[g2]];
  Print["  branch counts: ", g1, " has ", Length[branches1], "; ", g2, " has ", Length[branches2]];
  branchPairs = Tuples[{branches1, branches2}];
  If[g1 === g2 && ! $TreatEqualGroupFactorsAsOrdered,
    branchPairs = Select[branchPairs, OrderedQ[{vecKey[#[[1]]], vecKey[#[[2]]]}] &]
  ];
  Print["  raw branch-pairs: ", Length[branchPairs]];

  activeBranchPairs = Select[branchPairs,
    TrueQ[Together[etaDot[#[[1]], #[[2]]]/(repData[g1]["Lambda"] repData[g2]["Lambda"])] >= 0] &
  ];
  Print["  active branch-pairs with nonnegative mixed target: ", Length[activeBranchPairs]];

  countOneBP[bp_] := Length[n1ByGB[g1][bp[[1]]]] Length[n1ByGB[g2][bp[[2]]]];
  totalSpectrumPairs = Total[countOneBP /@ activeBranchPairs];
  Print["  one-factor spectrum pairs to scan: ", totalSpectrumPairs];

  printProgressQ[k_Integer] := TrueQ[$PrintPairScanProgress] && totalSpectrumPairs > 0 &&
    (k == 1 || k == totalSpectrumPairs || Mod[k - 1, $PairScanProgressEvery] == 0);

  t0 = AbsoluteTime[];
  Do[
    With[{b1 = bp[[1]], b2 = bp[[2]]},
      currentList1 = n1ByGB[g1][b1];
      currentList2 = n1ByGB[g2][b2];
      Do[
        spectrumPairCounter++;
        If[printProgressQ[spectrumPairCounter],
          Print["  ", spectrumPairCounter, "/", totalSpectrumPairs,
            "   elapsed=", NumberForm[AbsoluteTime[] - t0, {Infinity, 1}], "s",
            "   b1=", b1, " b2=", b2,
            "   n1 IDs=", s1["ID"], ",", s2["ID"]]
        ];
        partial = assembleFromTwoSpectra[g1, g2, b1, b2, s1, s2, repData];
        If[Length[partial] > 0,
          sols = Join[sols, partial]
        ];
        ,
        {s1, currentList1}, {s2, currentList2}
      ];
    ],
    {bp, activeBranchPairs}
  ];
  sols = DeleteDuplicatesBy[sols, solutionKey];
  Print["  finished ", g1, " x ", g2, ": ", Length[sols], " spectra."];
  writePairOutput[pairTag, sols, repData];
  <|"pair_index" -> pairIndex, "group1" -> g1, "group2" -> g2, "dimG1" -> dim1, "dimG2" -> dim2, "M_drone" -> mDrone, "count" -> Length[sols], "Solutions" -> sols|>
];

RunN2GTSA[] := Module[
  {repData, n1, n1Good, groups, pairs, n1ByGB, countsFile, allCounts = {}, allSolutions = {}, row},
  If[! DirectoryQ[$OutDir], CreateDirectory[$OutDir, CreateIntermediateDirectories -> True]];
  If[! DirectoryQ[$PairOutDir], CreateDirectory[$PairOutDir, CreateIntermediateDirectories -> True]];
  If[TrueQ[$CleanPairOutputFolderToTextOnly],
    Quiet[DeleteFile /@ Select[FileNames["*", $PairOutDir],
      FileType[#] === File && (MemberQ[{"wl", "wxf"}, ToLowerCase[FileExtension[#]]] ||
        StringMatchQ[FileNameTake[#], "*_count.txt"]) &
    ]]
  ];
  countsFile = FileNameJoin[{$OutDir, "n2_GTSA_pair_counts.csv"}];
  Quiet[If[FileExistsQ[countsFile], DeleteFile[countsFile]], DeleteFile::fdnfnd];

  Print["Loading representation data from ", $RepInfoFile];
  repData = loadRepData[$RepInfoFile];
  Print["Loaded groups: ", StringRiffle[Keys[repData], ", "]];

  Print["Parsing final n = 1 catalogue from ", $N1CataloguePDF];
  n1 = parseN1Catalogue[$N1CataloguePDF, repData];
  n1Good = Select[n1,
    (#["OneFactorChecks"]["quarticBResidual"] === 0 && #["OneFactorChecks"]["extraDResidual"] === 0 &&
      #["OneFactorChecks"]["normActual"] === #["OneFactorChecks"]["normRequired"]) &
  ];
  If[$RequireIntegralAnomalyVectors,
    n1Good = Select[n1Good, latticeAdmissibleQ[#["Branch"]] &]
  ];
  Print["One-factor spectra kept for n = 2 scan after the I_{1,1} lattice test: ", Length[n1Good]];

  groups = SortBy[Keys[GroupBy[n1Good, #["Group"] &]], {groupType[#] &, groupRank[#] &}];
  pairs = allGroupPairs[groups];
  Print["Raw gauge-group pairs before drone pruning: ", Length[pairs]];
  pairs = pruneNegativeDroneGroupLists[pairs, repData];
  Print["Gauge-group pairs to scan: ", Length[pairs]];
  n1ByGB = GroupBy[n1Good, {#["Group"] &, #["Branch"] &}];

  Do[
    row = scanOneGroupPair[i, pairs[[i, 1]], pairs[[i, 2]], n1ByGB, repData];
    AppendTo[allCounts, KeyDrop[row, "Solutions"]];
    allSolutions = DeleteDuplicatesBy[Join[allSolutions, Lookup[row, "Solutions", {}]], solutionKey];
    Print["  pair summary: ", row["group1"], " x ", row["group2"],
      " has ", row["count"], " spectra; total so far = ", Length[allSolutions], "."];
    appendCountCSV[KeyDrop[row, "Solutions"], countsFile];
    Export[FileNameJoin[{$OutDir, "n2_GTSA_all_spectra_so_far.wxf"}], allSolutions, "WXF"];
    Put[allSolutions, FileNameJoin[{$OutDir, "n2_GTSA_all_spectra_so_far.wl"}]];
    ,
    {i, Length[pairs]}
  ];

  allSolutions = DeleteDuplicatesBy[allSolutions, solutionKey];
  Export[FileNameJoin[{$OutDir, "n2_GTSA_all_spectra.wxf"}], allSolutions, "WXF"];
  Put[allSolutions, FileNameJoin[{$OutDir, "n2_GTSA_all_spectra.wl"}]];
  Export[FileNameJoin[{$OutDir, "n2_GTSA_all_spectra_readable.txt"}],
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum[#1, repData] &, allSolutions], "\n"],
    "Text"
  ];
  Export[FileNameJoin[{$OutDir, "n2_GTSA_pair_counts_final.csv"}], Normal /@ allCounts];

  If[TrueQ[$DeleteTemporaryFilesAfterFullScan],
    Quiet[DeleteFile /@ Select[{
      FileNameJoin[{$OutDir, "n2_GTSA_all_spectra_so_far.wl"}],
      FileNameJoin[{$OutDir, "n2_GTSA_all_spectra_so_far.wxf"}],
      countsFile
    }, FileExistsQ]];
    Print["Temporary checkpoint files deleted after successful full scan."]
  ];

  Print["\nFull n = 2 scan finished. Total spectra: ", Length[allSolutions]];
  <|"Counts" -> allCounts, "Solutions" -> allSolutions, "RepData" -> repData|>
];

If[TrueQ[$RunNow], RunN2GTSA[]];
