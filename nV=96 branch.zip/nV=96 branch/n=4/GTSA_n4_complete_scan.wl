(* ::Package:: *)
(*
  GTSA_n4_complete_scan.wl

  n = 4 GTSA scan for the n_V = 96 Sp(1)_R branch, using the revised off-diagonal anomaly-vector convention.

  Inputs, by default:
    C:\Physics\6d anomaly free models\n=4\RepInfo.nb
    C:\Physics\6d anomaly free models\n=4\n1_Sp1R_Catalogue.pdf
    C:\Physics\6d anomaly free models\n=4\n3_GTSA_all_spectra.wl

  Main implementation choices:
    - Uses final n = 3 spectra as the three-factor shadow block and the revised n = 1 catalogue as the fourth factor.
    - Recomputes every n = 1 branch vector from RepInfo.nb and checks it against the vector displayed in the PDF.
    - Checks the n = 3 group/branch data and third-factor source ID against the n = 1 catalogue.
    - Scans unordered quadruples G1 <= G2 <= G3 <= G4 with dim(G1)+dim(G2)+dim(G3)+dim(G4) <= 93.
    - For each candidate, it lifts three-factor matter (R1,R2,R3) and one-factor matter R4
      into four-factor matter (R1,R2,R3,R4).
    - Every pairwise mixed anomaly is checked against the shadow pairing:
          sum_H A_i(R_i) A_j(R_j) prod_{k != i,j} dim(R_k) == b_i.b_j/(lambda_i lambda_j).
    - The full local anomaly matrix in basis
          (tr R^2, tr_2 F_R^2, tr F_1^2, tr F_2^2, tr F_3^2, tr F_4^2)
      is recomputed and must have rank <= 2.
    - Half-integer multiplicities are allowed only when the full product representation is pseudoreal.
      PS = 1/2 means pseudoreal.  PS = 1 is split into real/complex using Dynkin conjugation.
    - Duplicate spectra under permutations of identical simple factors are quotiented by a canonical key.
    - Quadruple output folder receives readable .txt files only; final WL/WXF/TXT/CSV are written at the end.
*)

(* Do not ClearAll["Global`*"] here: users may set options such as $ReverseGroupQuadrupleOrder before Get[]. *)

(* ---------------------------------------------------------------------- *)
(* User settings                                                          *)
(* ---------------------------------------------------------------------- *)

$GTSAN4ScanVersion = "new-offdiag-convention-n1-n3-crosscheck-v1-20260715";

If[! ValueQ[$BaseDir], $BaseDir = "C:\\Physics\\6d anomaly free models\\n=4"];
If[! ValueQ[$RepInfoFile], $RepInfoFile = FileNameJoin[{$BaseDir, "RepInfo.nb"}]];
If[! ValueQ[$N1CataloguePDF], $N1CataloguePDF = FileNameJoin[{$BaseDir, "n1_Sp1R_Catalogue.pdf"}]];
If[! ValueQ[$N3SpectraWL], $N3SpectraWL = FileNameJoin[{$BaseDir, "n3_GTSA_all_spectra.wl"}]];

If[! ValueQ[$OutDir], $OutDir = FileNameJoin[{$BaseDir, "n4_GTSA_complete_outputs"}]];
If[! ValueQ[$QuadrupleOutDir], $QuadrupleOutDir = FileNameJoin[{$OutDir, "quadruple_outputs"}]];

If[! ValueQ[$ReverseGroupQuadrupleOrder], $ReverseGroupQuadrupleOrder = False];
If[! ValueQ[$RequireIntegralAnomalyVectors], $RequireIntegralAnomalyVectors = True];
If[! ValueQ[$RequireNonnegativeDroneCount], $RequireNonnegativeDroneCount = True];
If[! ValueQ[$PruneNegativeDroneQuadruplesAtStart], $PruneNegativeDroneQuadruplesAtStart = True];
If[! ValueQ[$QuotientIdenticalFactorPermutation], $QuotientIdenticalFactorPermutation = True];
If[! ValueQ[$CleanQuadrupleOutputFolderToTextOnly], $CleanQuadrupleOutputFolderToTextOnly = True];
If[! ValueQ[$DeleteTemporaryFilesAfterFullScan], $DeleteTemporaryFilesAfterFullScan = True];
If[! ValueQ[$RunNow], $RunNow = True];

(* Progress inside each fixed group quadruple. *)
If[! ValueQ[$PrintQuadrupleScanProgress], $PrintQuadrupleScanProgress = True];
If[! ValueQ[$QuadrupleScanProgressEvery], $QuadrupleScanProgressEvery = 1000];
If[! ValueQ[$PrintKeyDiagnostics], $PrintKeyDiagnostics = True];

(* Safety/debug switches. *)
If[! ValueQ[$CheckN3InputLocalPass], $CheckN3InputLocalPass = True];
If[! ValueQ[$CheckN3SourceAgainstN1], $CheckN3SourceAgainstN1 = True];
If[! ValueQ[$CheckN3BranchLattice], $CheckN3BranchLattice = True];
If[! ValueQ[$ExpectedN1SpectrumCount], $ExpectedN1SpectrumCount = 652];
If[! ValueQ[$ExpectedN3SpectrumCount], $ExpectedN3SpectrumCount = 1092];
If[! ValueQ[$AbortOnBadInput], $AbortOnBadInput = True];

(* Optional scan controls.  Leave as defaults for the full scan. *)
If[! ValueQ[$StartQuadrupleIndex], $StartQuadrupleIndex = 1];
If[! ValueQ[$EndQuadrupleIndex], $EndQuadrupleIndex = Infinity];
If[! ValueQ[$OnlyGroupQuadruples], $OnlyGroupQuadruples = All];

$nV = 96;
$nH = $nV + 244;
$dimNonRMax = $nV - 3;   (* 93 = 96 - dim Sp(1)_R *)

(* Off-diagonal coordinate convention used in the revised n_V = 96 catalogues. *)
$aVec = {-2, -2};
$bRVec = {3/2, -5};

(* ---------------------------------------------------------------------- *)
(* General utilities                                                      *)
(* ---------------------------------------------------------------------- *)

etaDot[u_List, v_List] := u[[1]] v[[2]] + u[[2]] v[[1]];
etaNorm[u_List] := etaDot[u, u];
innerRow[u_List] := {u[[2]], u[[1]]};

(* In these displayed off-diagonal coordinates, the integral odd I_{1,1}
   lattice is the image of Z^2 under (m,n) -> ((m+n)/2,m-n). *)
latticeAdmissibleQ[v_List] := Module[{twox = Together[2 v[[1]]], y = Together[v[[2]]]},
  IntegerQ[twox] && IntegerQ[y] && EvenQ[twox - y]
];

safeName[s_String] := StringReplace[s, Except[WordCharacter] -> "_"];
vecKey[v_List] := ToString[InputForm[v]];

positiveAssoc[a_Association] := Association @ KeyValueMap[If[#2 === 0, Nothing, #1 -> #2] &, a];

formatRational[x_] := Which[
  IntegerQ[x], ToString[x],
  Denominator[x] == 2 && Numerator[x] == 1, "1/2",
  Denominator[x] == 2, ToString[Numerator[x]] <> "/2",
  True, ToString[InputForm[x]]
];
formatMult[x_] := If[x === 1, "", formatRational[x] <> " x "];

ratRange[max_, step_] := Table[i step, {i, 0, Floor[max/step]}];

subtractAssoc[a_Association, key_, amount_] := Module[{val},
  val = assocGet[a, key, 0] - amount;
  If[val < 0, Return[$Failed]];
  If[val === 0, assocDropKey[a, key], assocPut[a, key, val]]
];

vectorNonnegativeQ[v_List] := AllTrue[v, TrueQ[# >= 0] &];

(* Association helpers for keys that are themselves lists, e.g. {Rep1,Rep2}.
   Lookup[assoc, {a,b}, def] means lookup two separate keys a and b, not the
   composite key {a,b}.  Therefore composite keys must be accessed by assoc[key]
   after KeyExistsQ, and dropped as a one-element key list {key}. *)
assocGet[a_Association, key_, default_:0] := If[KeyExistsQ[a, key], a[key], default];
assocDropKey[a_Association, key_] := KeyDrop[a, {key}];
assocPut[a_Association, key_, value_] := Association[assocDropKey[a, key], key -> value];

(* ---------------------------------------------------------------------- *)
(* Lie-group conventions                                                  *)
(* ---------------------------------------------------------------------- *)

groupType[g_String] := StringTake[g, 1];
groupRank[g_String] := ToExpression[StringDrop[g, 1]];

groupSortKey[g_String] := {Switch[groupType[g], "A", 1, "B", 2, "C", 3, "D", 4, "E", 5, "F", 6, "G", 7, _, 99], groupRank[g]};

lambdaFactor[g_String] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", 1,
    "B", 2,
    "C", 1,
    "D", 2,
    "E", Switch[n, 6, 6, 7, 12, 8, 60, _, Missing["UnknownLambda", g]],
    "F", 6,
    "G", 2,
    _, Missing["UnknownLambda", g]
  ]
];

normalizeGroupName[Subscript[s_, n_Integer]] := ToUpperCase[StringTake[SymbolName[Unevaluated[s]], 1]] <> ToString[n];
normalizeGroupName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {
    "Subscript[a, " ~~ n : DigitCharacter.. ~~ "]" :> "A" <> n,
    "Subscript[b, " ~~ n : DigitCharacter.. ~~ "]" :> "B" <> n,
    "Subscript[c, " ~~ n : DigitCharacter.. ~~ "]" :> "C" <> n,
    "Subscript[d, " ~~ n : DigitCharacter.. ~~ "]" :> "D" <> n,
    "Subscript[e, " ~~ n : DigitCharacter.. ~~ "]" :> "E" <> n,
    "Subscript[f, " ~~ n : DigitCharacter.. ~~ "]" :> "F" <> n,
    "Subscript[g, " ~~ n : DigitCharacter.. ~~ "]" :> "G" <> n
  }]
];

normalizeRepName[Subscript[r_, n_Integer]] := "r" <> ToString[n];
normalizeRepName[s_Symbol] := SymbolName[Unevaluated[s]];
normalizeRepName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {"Subscript[r, " ~~ n : DigitCharacter.. ~~ "]" :> "r" <> n}]
];

(* Dynkin-label conjugation.  PS == 1 is not enough: A_n, D_odd and E6 can be complex. *)
conjugateDynkin[g_String, dyn_List] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", Reverse[dyn],
    "D", If[OddQ[n], ReplacePart[dyn, {n - 1 -> dyn[[n]], n -> dyn[[n - 1]]}], dyn],
    "E", If[n == 6, dyn[[{5, 4, 3, 2, 1, 6}]], dyn],
    _, dyn
  ]
];

realityType[g_String, ps_, dyn_List] := Which[
  ps === 1/2, "Pseudoreal",
  ps === Rational[1, 2], "Pseudoreal",
  conjugateDynkin[g, dyn] === dyn, "Real",
  True, "Complex"
];

productRealityFromReps[repList_List] := Module[{types, prCount},
  types = repList[[All, "Reality"]];
  If[MemberQ[types, "Complex"], Return["Complex"]];
  prCount = Count[types, "Pseudoreal"];
  If[OddQ[prCount], "Pseudoreal", "Real"]
];

productPseudoRealQ[repList_List] := productRealityFromReps[repList] === "Pseudoreal";

allowedProductMultiplicityQ[m_, repList_List] := IntegerQ[m] || (productPseudoRealQ[repList] && IntegerQ[2 m]);

(* ---------------------------------------------------------------------- *)
(* Load RepInfo.nb                                                        *)
(* ---------------------------------------------------------------------- *)

loadNotebookInputs[file_] := Module[{inputs},
  Clear[reps];
  inputs = Quiet @ Check[NotebookImport[file, "Input"], $Failed];
  If[inputs === $Failed, inputs = Quiet @ Check[NotebookImport[file, "InputText"], $Failed]];
  If[inputs === $Failed,
    Print["Could not import input cells from ", file]; Abort[]
  ];
  Scan[
    Function[expr,
      Quiet @ Check[ReleaseHold[expr], Null];
      If[! ValueQ[reps], Quiet @ Check[ToExpression[ToString[Unevaluated[expr], InputForm]], Null]];
      If[StringQ[expr] && ! ValueQ[reps], Quiet @ Check[ToExpression[expr], Null]];
    ],
    Flatten[{inputs}]
  ];
  If[! ValueQ[reps], Print["The symbol reps was not defined after reading ", file]; Abort[]];
  reps
];

buildRepData[repRules_] := Association @ Map[
  Function[grule,
    Module[{g, raw, repAssoc},
      g = normalizeGroupName[grule[[1]]];
      raw = grule[[2]];
      repAssoc = Association @ MapIndexed[
        Function[{rr, idx},
          Module[{nm, coeffs, dyn, dimv, ps},
            nm = normalizeRepName[rr[[1]]];
            coeffs = Association[rr[[2]]];
            dyn = Lookup[coeffs, dynkin];
            dimv = Lookup[coeffs, dim];
            ps = Lookup[coeffs, PS];
            nm -> <|
              "Name" -> nm,
              "Index" -> idx[[1]],
              "Dynkin" -> dyn,
              "Dim" -> dimv,
              "PS" -> ps,
              "Reality" -> realityType[g, ps, dyn],
              "QuarticB" -> Lookup[coeffs, Global`a],
              "QuadC" -> Lookup[coeffs, Global`b],
              "IndexA" -> Lookup[coeffs, Global`c],
              "ExtraD" -> Lookup[coeffs, Global`d]
            |>
          ]
        ],
        raw
      ];
      g -> <|
        "Group" -> g,
        "Rank" -> groupRank[g],
        "Lambda" -> lambdaFactor[g],
        "Reps" -> repAssoc,
        "DimG" -> repAssoc["adj"]["Dim"]
      |>
    ]
  ],
  repRules
];

loadRepData[file_] := buildRepData[loadNotebookInputs[file]];

(* ---------------------------------------------------------------------- *)
(* Parse n = 1 catalogue                                                  *)
(* ---------------------------------------------------------------------- *)

findRepByDynkinDim[repData_, g_String, dyn_List, dimv_Integer] := Module[{lst, hit},
  lst = Values[repData[g]["Reps"]];
  hit = Select[lst, (# ["Dynkin"] === dyn && # ["Dim"] === dimv) &];
  If[Length[hit] != 1,
    Print["Could not uniquely match representation in ", g, ": dynkin=", dyn, ", dim=", dimv, "; matches=", Length[hit]];
    Abort[]
  ];
  First[hit]
];

parseSpectrumTerms[spec_String, g_String, repData_] := Module[{termRE, rawTerms},
  termRE = RegularExpression["(\\d+)\\s*x\\s*\\(([^\\)]*)\\)\\s*(\\d+)\\s*(half)?"];
  rawTerms = StringCases[spec, termRE -> {"$1", "$2", "$3", "$4"}];
  Map[
    Function[t,
      Module[{m0, dyn, dimv, half, rep, mult},
        m0 = ToExpression[t[[1]]];
        dyn = ToExpression["{" <> StringReplace[t[[2]], WhitespaceCharacter .. -> ""] <> "}"];
        dimv = ToExpression[t[[3]]];
        half = StringTrim[t[[4]]] === "half";
        rep = findRepByDynkinDim[repData, g, dyn, dimv];
        mult = If[half, m0/2, m0];
        If[! allowedProductMultiplicityQ[mult, {rep}],
          Print["Bad one-factor multiplicity in PDF for ", g, ": ", mult, " x ", rep["Name"], " has reality ", rep["Reality"]];
          Abort[]
        ];
        <|"Rep" -> rep["Name"], "Mult" -> mult|>
      ]
    ],
    rawTerms
  ]
];

repAssocFromN1Entries[entries_List] := Merge[(# ["Rep"] -> # ["Mult"]) & /@ entries, Total];

spectrumSumsOneFactor[sp_Association, repData_] := Module[{g = sp["Group"], reps, entries},
  reps = repData[g]["Reps"];
  entries = sp["Entries"];
  <|
    "IndexA" -> Total[(# ["Mult"] reps[# ["Rep"]]["IndexA"]) & /@ entries],
    "QuadC" -> Total[(# ["Mult"] reps[# ["Rep"]]["QuadC"]) & /@ entries],
    "QuarticB" -> Total[(# ["Mult"] reps[# ["Rep"]]["QuarticB"]) & /@ entries],
    "ExtraD" -> Total[(# ["Mult"] reps[# ["Rep"]]["ExtraD"]) & /@ entries]
  |>
];

deriveBranchVector[sp_Association, repData_] := Module[
  {g = sp["Group"], lam, adj, sums, dotA, dotR, mat, vec, normReq, checks},
  lam = repData[g]["Lambda"];
  adj = repData[g]["Reps"]["adj"];
  sums = spectrumSumsOneFactor[sp, repData];
  dotA = lam/6 (adj["IndexA"] - sums["IndexA"]);
  dotR = -lam adj["IndexA"]/2;
  mat = {innerRow[$aVec], innerRow[$bRVec]};
  vec = Together[LinearSolve[mat, {dotA, dotR}]];
  normReq = lam^2/3 (sums["QuadC"] - adj["QuadC"]);
  checks = <|
    "aDot" -> dotA,
    "bRDot" -> dotR,
    "normRequired" -> Together[normReq],
    "normActual" -> Together[etaNorm[vec]],
    "quarticBResidual" -> Together[adj["QuarticB"] - sums["QuarticB"]],
    "extraDResidual" -> Together[adj["ExtraD"] - sums["ExtraD"]]
  |>;
  {vec, checks}
];

parseN1Catalogue[pdfFile_, repData_] := Module[
  {txt, clean, groups, headers, blocks, rowRE, spectra},
  If[! FileExistsQ[pdfFile], Print["n = 1 catalogue not found: ", pdfFile]; Abort[]];
  txt = Import[pdfFile, "Plaintext"];
  clean = StringReplace[txt, {"\r" -> " ", "\n" -> " ", WhitespaceCharacter .. -> " "}];
  groups = Keys[repData];
  headers = SortBy[
    Flatten[
      Table[(Append[#, g] & /@ StringPosition[clean, g <> " spectra"]), {g, groups}],
      1
    ],
    First
  ];
  headers = DeleteDuplicatesBy[headers, {# [[1]], # [[3]]} &];
  blocks = Table[
    Module[{start = headers[[i, 2]] + 1, stop, g = headers[[i, 3]]},
      stop = If[i < Length[headers], headers[[i + 1, 1]] - 1, StringLength[clean]];
      {g, StringTake[clean, {start, stop}]}
    ],
    {i, Length[headers]}
  ];

  (* Revised n=1 rows have the form
       ID  (b_x,b_y)  singlets  H_charged  charged spectrum.
     The branch displayed in the PDF is checked against an independent
     recomputation from RepInfo.nb. *)
  rowRE = RegularExpression[
    "(\\d+)\\s+\\(\\s*(-?\\d+(?:/\\d+)?)\\s*,\\s*(-?\\d+(?:/\\d+)?)\\s*\\)\\s+" <>
    "(\\d+)\\s+(\\d+)\\s+(.*?)(?=(?:\\s\\d+\\s+\\(\\s*-?\\d+(?:/\\d+)?\\s*,\\s*-?\\d+(?:/\\d+)?\\s*\\)\\s+\\d+\\s+\\d+\\s+)|$)"
  ];
  spectra = Flatten[
    Map[
      Function[blk,
        Module[{g = blk[[1]], block = blk[[2]], rows},
          rows = StringCases[block, rowRE -> {"$1", "$2", "$3", "$4", "$5", "$6"}];
          Map[
            Function[r,
              Module[{sp, br, shownBr, checks},
                shownBr = ToExpression /@ r[[{2, 3}]];
                sp = <|
                  "ID" -> ToExpression[r[[1]]],
                  "Group" -> g,
                  "Singlets" -> ToExpression[r[[4]]],
                  "HCharged" -> ToExpression[r[[5]]],
                  "Entries" -> parseSpectrumTerms[r[[6]], g, repData]
                |>;
                {br, checks} = deriveBranchVector[sp, repData];
                If[br =!= shownBr,
                  Print["Displayed/recomputed branch mismatch for n=1 ID ", sp["ID"],
                    ": displayed=", shownBr, ", recomputed=", br];
                  Abort[]
                ];
                Join[sp, <|"Branch" -> br, "OneFactorChecks" -> checks|>]
              ]
            ],
            rows
          ]
        ]
      ],
      blocks
    ],
    1
  ];
  Print["Parsed ", Length[spectra], " one-factor spectra from ", pdfFile];
  spectra
];


(* ---------------------------------------------------------------------- *)
(* Load/check n = 3 spectra                                               *)
(* ---------------------------------------------------------------------- *)

loadN3Spectra[file_] := Module[{data},
  If[! FileExistsQ[file], Print["n = 3 spectrum file not found: ", file]; Abort[]];
  data = Get[file];
  If[! ListQ[data], Print["n = 3 file did not evaluate to a list: ", file]; Abort[]];
  Print["Loaded ", Length[data], " n = 3 spectra from ", file];
  data
];


validateN3AgainstN1[n3_List, n1_List] := Module[
  {n1ByID, n1BranchKeys, bad},
  n1ByID = Association[(# ["ID"] -> #) & /@ n1];
  n1BranchKeys = Association[(# -> True) & /@ DeleteDuplicates[({# ["Group"], # ["Branch"]} &) /@ n1]];
  bad = Select[n3,
    Module[{groups, branches, id3, source3, n2groups},
      groups = Lookup[#, "Groups", Missing["Groups"]];
      branches = Lookup[#, "Branches", Missing["Branches"]];
      If[! ListQ[groups] || ! ListQ[branches] || Length[groups] =!= 3 || Length[branches] =!= 3, Return[True]];
      If[! AllTrue[MapThread[{#1, #2} &, {groups, branches}], KeyExistsQ[n1BranchKeys, #] &], Return[True]];
      id3 = Lookup[#, "N1ID3", Missing["N1ID3"]];
      If[! KeyExistsQ[n1ByID, id3], Return[True]];
      source3 = n1ByID[id3];
      If[! (source3["Group"] === groups[[3]] && source3["Branch"] === branches[[3]]), Return[True]];
      n2groups = Lookup[#, "N2Groups", Take[groups, 2]];
      n2groups =!= Take[groups, 2]
    ] &
  ];
  If[Length[bad] > 0,
    Print["Found ", Length[bad], " n = 3 spectra whose groups, branches, or third-factor n = 1 source ID do not match the n = 1 catalogue."];
    Print["First mismatches: ", Take[bad, UpTo[5]]];
    False,
    Print["All n = 3 group/branch data and third-factor n = 1 source IDs agree with the n = 1 catalogue."];
    True
  ]
];

n3BranchesLatticeAdmissibleQ[sp_Association] :=
  AllTrue[sp["Branches"], latticeAdmissibleQ];

n3SpectrumKeyForGrouping[sp_Association] := sp["Groups"];

validN3SpectrumBlockQ[sp_] := AssociationQ[sp] && KeyExistsQ[sp, "Groups"] &&
  KeyExistsQ[sp, "Branches"] && KeyExistsQ[sp, "Entries"] && Length[sp["Groups"]] == 3 && Length[sp["Branches"]] == 3;

repAssocFromN3Entries[entries_List] := Merge[({# ["Rep1"], # ["Rep2"], # ["Rep3"]} -> # ["Mult"]) & /@ entries, Total];

(* ---------------------------------------------------------------------- *)
(* Product-representation helpers                                         *)
(* ---------------------------------------------------------------------- *)

repDataForKey123[key_List, groups_List, repData_] := MapThread[repData[#1]["Reps"][#2] &, {groups, key}];
repDataForKey1234[key_List, groups_List, repData_] := MapThread[repData[#1]["Reps"][#2] &, {groups, key}];

allowedLeftover123Q[rem123_Association, groups3_List, repData_] :=
  AllTrue[Normal[rem123], allowedProductMultiplicityQ[# [[2]], repDataForKey123[# [[1]], groups3, repData]] &];

allowedLeftover1Q[rem1_Association, g_, repData_] :=
  AllTrue[Normal[rem1], allowedProductMultiplicityQ[# [[2]], {repData[g]["Reps"][# [[1]]]}] &];

allowedQuadMultiplicityQ[m_, r1_, r2_, r3_, r4_] := allowedProductMultiplicityQ[m, {r1, r2, r3, r4}];

(* ---------------------------------------------------------------------- *)
(* Build/check n = 4 spectra                                              *)
(* ---------------------------------------------------------------------- *)

buildEntriesFromState4[g1_, g2_, g3_, g4_, rem123_, rem4_, links_] := Module[{left123, left4, linkEntries},
  left123 = KeyValueMap[<|"Rep1" -> #1[[1]], "Rep2" -> #1[[2]], "Rep3" -> #1[[3]], "Rep4" -> "r0", "Mult" -> #2|> &, rem123];
  left4 = KeyValueMap[<|"Rep1" -> "r0", "Rep2" -> "r0", "Rep3" -> "r0", "Rep4" -> #1, "Mult" -> #2|> &, rem4];
  linkEntries = Map[<|"Rep1" -> #[[1, 1]], "Rep2" -> #[[1, 2]], "Rep3" -> #[[1, 3]], "Rep4" -> #[[2]], "Mult" -> #[[3]]|> &, links];
  Select[Join[linkEntries, left123, left4], # ["Mult"] =!= 0 &]
];

entryRepNames4[e_] := {e["Rep1"], e["Rep2"], e["Rep3"], e["Rep4"]};
entryDims4[e_, groups_, repData_] := MapThread[repData[#1]["Reps"][#2]["Dim"] &, {groups, entryRepNames4[e]}];
entryA4[e_, groups_, repData_] := MapThread[repData[#1]["Reps"][#2]["IndexA"] &, {groups, entryRepNames4[e]}];

chargedHDim4[entries_List, groups_List, repData_] := Total[(# ["Mult"] Times @@ entryDims4[#, groups, repData]) & /@ entries];

localAnomalyMatrixAndCheck4[entries_List, singlets_, groups_List, branches_List, repData_] := Module[
  {reps, lams, adjs, sums, mixed, coeffRF, coeffFF, mat, rank, quartic, dres, expectedMixed, mixedResiduals, i, j, n = 4},
  reps = (repData[#]["Reps"] &) /@ groups;
  lams = (repData[#]["Lambda"] &) /@ groups;
  adjs = (# ["adj"] &) /@ reps;

  sums = Table[
    <|
      "IndexA" -> Total[(# ["Mult"] Times @@ Delete[entryDims4[#, groups, repData], i] * entryA4[#, groups, repData][[i]]) & /@ Select[entries, entryRepNames4[#][[i]] =!= "r0" &]],
      "QuadC" -> Total[(# ["Mult"] Times @@ Delete[entryDims4[#, groups, repData], i] * reps[[i]][entryRepNames4[#][[i]]]["QuadC"]) & /@ Select[entries, entryRepNames4[#][[i]] =!= "r0" &]],
      "QuarticB" -> Total[(# ["Mult"] Times @@ Delete[entryDims4[#, groups, repData], i] * reps[[i]][entryRepNames4[#][[i]]]["QuarticB"]) & /@ Select[entries, entryRepNames4[#][[i]] =!= "r0" &]],
      "ExtraD" -> Total[(# ["Mult"] Times @@ Delete[entryDims4[#, groups, repData], i] * reps[[i]][entryRepNames4[#][[i]]]["ExtraD"]) & /@ Select[entries, entryRepNames4[#][[i]] =!= "r0" &]]
    |>,
    {i, n}
  ];

  mixed = Association @ Flatten[
    Table[
      {i, j} -> Total[(# ["Mult"] Times @@ Delete[entryDims4[#, groups, repData], {{j}, {i}}] * entryA4[#, groups, repData][[i]] * entryA4[#, groups, repData][[j]]) & /@ Select[entries, entryRepNames4[#][[i]] =!= "r0" && entryRepNames4[#][[j]] =!= "r0" &]],
      {i, 1, n - 1}, {j, i + 1, n}
    ],
    1
  ];

  expectedMixed = Association @ Flatten[
    Table[{i, j} -> Together[etaDot[branches[[i]], branches[[j]]]/(lams[[i]] lams[[j]])], {i, 1, n - 1}, {j, i + 1, n}],
    1
  ];
  mixedResiduals = Association @ KeyValueMap[#1 -> Together[#2 - expectedMixed[#1]] &, mixed];

  quartic = Table[Together[adjs[[i]]["QuarticB"] - sums[[i]]["QuarticB"]], {i, n}];
  dres = Table[Together[adjs[[i]]["ExtraD"] - sums[[i]]["ExtraD"]], {i, n}];
  coeffRF = Table[1/6 (adjs[[i]]["IndexA"] - sums[[i]]["IndexA"]), {i, n}];
  coeffFF = Table[2/3 (sums[[i]]["QuadC"] - adjs[[i]]["QuadC"]), {i, n}];

  mat = ConstantArray[0, {2 + n, 2 + n}];
  mat[[1, 1]] = 1;
  mat[[1, 2]] = mat[[2, 1]] = ($nV - 12)/24;
  mat[[2, 2]] = -($nV + 84)/6;
  Do[
    mat[[1, 2 + i]] = mat[[2 + i, 1]] = coeffRF[[i]]/2;
    mat[[2, 2 + i]] = mat[[2 + i, 2]] = -adjs[[i]]["IndexA"];
    mat[[2 + i, 2 + i]] = coeffFF[[i]],
    {i, n}
  ];
  Do[
    mat[[2 + i, 2 + j]] = mat[[2 + j, 2 + i]] = 2 mixed[{i, j}],
    {i, 1, n - 1}, {j, i + 1, n}
  ];
  mat = Together[mat];
  rank = MatrixRank[mat];

  <|
    "Pass" -> (AllTrue[quartic, # === 0 &] && AllTrue[dres, # === 0 &] && AllTrue[Values[mixedResiduals], # === 0 &] && rank <= 2),
    "Rank" -> rank,
    "Matrix" -> mat,
    "QuarticResiduals" -> quartic,
    "DResiduals" -> dres,
    "Mixed" -> mixed,
    "ExpectedMixed" -> expectedMixed,
    "MixedResiduals" -> mixedResiduals
  |>
];

(* ---------------------------------------------------------------------- *)
(* Canonical keys and readable formatting                                  *)
(* ---------------------------------------------------------------------- *)

entryKeyList4[entries_List] := Sort[({# ["Rep1"], # ["Rep2"], # ["Rep3"], # ["Rep4"], # ["Mult"]} & /@ entries)];

permuteEntry4[e_Association, p_List] := Module[{reps = entryRepNames4[e]},
  <|"Rep1" -> reps[[p[[1]]]], "Rep2" -> reps[[p[[2]]]], "Rep3" -> reps[[p[[3]]]], "Rep4" -> reps[[p[[4]]]], "Mult" -> e["Mult"]|>
];

sameGroupPermutations4[groups_List] := Select[Permutations[Range[4]], groups[[#]] === groups &];

solutionKey4[sol_Association] := Module[{groups = sol["Groups"], perms, keyData},
  perms = If[TrueQ[$QuotientIdenticalFactorPermutation], sameGroupPermutations4[groups], {Range[4]}];
  keyData = Table[
    {groups[[p]], sol["Branches"][[p]], sol["Singlets"], entryKeyList4[permuteEntry4[#, p] & /@ sol["Entries"]]},
    {p, perms}
  ];
  ToString[InputForm[First[Sort[keyData]]]]
];

formatRepShort[g_, rep_, repData_] := Module[{r = repData[g]["Reps"][rep]},
  If[rep === "r0", "1", "(" <> StringRiffle[ToString /@ r["Dynkin"], ","] <> ")_" <> ToString[r["Dim"]]]
];

formatEntry4[e_, groups_, repData_] := formatMult[e["Mult"]] <> "(" <>
  StringRiffle[MapThread[formatRepShort[#1, #2, repData] &, {groups, entryRepNames4[e]}], ","] <> ")";

formatSpectrum4[sol_, repData_] := Module[{terms},
  terms = Join[
    If[sol["Singlets"] === 0, {}, {formatMult[sol["Singlets"]] <> "(1,1,1,1)"}],
    formatEntry4[#, sol["Groups"], repData] & /@ sol["Entries"]
  ];
  StringRiffle[Select[terms, StringLength[#] > 0 &], " + "]
];

(* ---------------------------------------------------------------------- *)
(* Assembly: n = 3 block paired with an n = 1 factor                       *)
(* ---------------------------------------------------------------------- *)

assembleFromN3AndN1[n3sp_Association, n1sp_Association, repData_] := Module[
  {groups3, g1, g2, g3, g4, groups, branches3, b1, b2, b3, b4, branches,
   reps1, reps2, reps3, reps4, lams, target, rem123, rem4, keys123, keys4,
   edges, edgeData, solutions = {}, recurse},

  groups3 = n3sp["Groups"];
  {g1, g2, g3} = groups3;
  g4 = n1sp["Group"];
  groups = {g1, g2, g3, g4};
  branches3 = n3sp["Branches"];
  {b1, b2, b3} = branches3;
  b4 = n1sp["Branch"];
  branches = {b1, b2, b3, b4};

  reps1 = repData[g1]["Reps"]; reps2 = repData[g2]["Reps"]; reps3 = repData[g3]["Reps"]; reps4 = repData[g4]["Reps"];
  lams = (repData[#]["Lambda"] &) /@ groups;

  target = Together[Table[etaDot[branches[[i]], b4]/(lams[[i]] lams[[4]]), {i, 3}]];
  If[! vectorNonnegativeQ[target], Return[{}]];

  rem123 = positiveAssoc @ repAssocFromN3Entries[n3sp["Entries"]];
  rem4 = positiveAssoc @ KeyDrop[repAssocFromN1Entries[n1sp["Entries"]], "r0"];
  keys123 = Keys[rem123]; keys4 = Keys[rem4];

  edges = Select[Tuples[{keys123, keys4}],
    Module[{k123 = #[[1]], r4n = #[[2]], a1, a2, a3, a4},
      a1 = reps1[k123[[1]]]["IndexA"]; a2 = reps2[k123[[2]]]["IndexA"];
      a3 = reps3[k123[[3]]]["IndexA"]; a4 = reps4[r4n]["IndexA"];
      a4 (a1 + a2 + a3) > 0
    ] &
  ];

  edgeData = SortBy[
    Map[
      Function[e,
        Module[{k123 = e[[1]], r4n = e[[2]], r1, r2, r3, r4, d1, d2, d3, d4, a1, a2, a3, a4, cvec, step},
          r1 = reps1[k123[[1]]]; r2 = reps2[k123[[2]]]; r3 = reps3[k123[[3]]]; r4 = reps4[r4n];
          d1 = r1["Dim"]; d2 = r2["Dim"]; d3 = r3["Dim"]; d4 = r4["Dim"];
          a1 = r1["IndexA"]; a2 = r2["IndexA"]; a3 = r3["IndexA"]; a4 = r4["IndexA"];
          cvec = Together[{a1 a4 d2 d3, a2 a4 d1 d3, a3 a4 d1 d2}];
          step = If[productPseudoRealQ[{r1, r2, r3, r4}], 1/2, 1];
          <|"Key123" -> k123, "Rep4" -> r4n, "Dim123" -> d1 d2 d3, "Dim4" -> d4,
            "Contrib" -> cvec, "Step" -> step, "RepData" -> {r1, r2, r3, r4}|>
        ]
      ],
      edges
    ],
    -Total[# ["Contrib"]] &
  ];

  recurse[i_, remTarget_, cur123_, cur4_, links_] := Module[
    {ed, bounds, max, vals, new123, new4, entries, hdim, sing, check, sol},
    If[! vectorNonnegativeQ[remTarget], Return[Null]];
    If[remTarget === {0, 0, 0},
      If[! allowedLeftover123Q[cur123, groups3, repData] || ! allowedLeftover1Q[cur4, g4, repData], Return[Null]];
      entries = buildEntriesFromState4[g1, g2, g3, g4, cur123, cur4, links];
      If[! AllTrue[entries, allowedProductMultiplicityQ[# ["Mult"], repDataForKey1234[entryRepNames4[#], groups, repData]] &], Return[Null]];
      hdim = chargedHDim4[entries, groups, repData];
      sing = Together[$nH - hdim];
      If[sing < 0 || ! IntegerQ[sing], Return[Null]];
      check = localAnomalyMatrixAndCheck4[entries, sing, groups, branches, repData];
      If[! TrueQ[check["Pass"]], Return[Null]];
      sol = <|
        "Groups" -> groups,
        "Branches" -> branches,
        "N3ID" -> Lookup[n3sp, "SpectrumID", Missing["NotAvailable"]],
        "N3Groups" -> groups3,
        "N1ID4" -> n1sp["ID"],
        "Singlets" -> sing,
        "Entries" -> SortBy[entries, {# ["Rep1"] &, # ["Rep2"] &, # ["Rep3"] &, # ["Rep4"] &, # ["Mult"] &}],
        "LocalCheck" -> check
      |>;
      AppendTo[solutions, sol];
      Return[Null]
    ];
    If[i > Length[edgeData], Return[Null]];
    ed = edgeData[[i]];
    bounds = Join[
      {assocGet[cur123, ed["Key123"], 0]/ed["Dim4"], assocGet[cur4, ed["Rep4"], 0]/ed["Dim123"]},
      Table[If[ed["Contrib"][[k]] > 0, remTarget[[k]]/ed["Contrib"][[k]], Infinity], {k, 3}]
    ];
    max = Min[bounds];
    If[max === Infinity, max = Min[assocGet[cur123, ed["Key123"], 0]/ed["Dim4"], assocGet[cur4, ed["Rep4"], 0]/ed["Dim123"]]];
    vals = ratRange[max, ed["Step"]];
    Scan[
      Function[x,
        If[! allowedQuadMultiplicityQ[x, Sequence @@ ed["RepData"]], Return[Null]];
        new123 = subtractAssoc[cur123, ed["Key123"], ed["Dim4"] x];
        If[new123 === $Failed, Return[Null]];
        new4 = subtractAssoc[cur4, ed["Rep4"], ed["Dim123"] x];
        If[new4 === $Failed, Return[Null]];
        recurse[i + 1, Together[remTarget - x ed["Contrib"]], new123, new4,
          If[x === 0, links, Append[links, {ed["Key123"], ed["Rep4"], x}]]]
      ],
      vals
    ];
  ];

  recurse[1, target, rem123, rem4, {}];
  DeleteDuplicatesBy[solutions, solutionKey4]
];

(* ---------------------------------------------------------------------- *)
(* Output                                                                 *)
(* ---------------------------------------------------------------------- *)

writeQuadrupleOutput[quadTag_, sols_, repData_] := Module[{txtFile, readable},
  If[! DirectoryQ[$QuadrupleOutDir], CreateDirectory[$QuadrupleOutDir, CreateIntermediateDirectories -> True]];
  txtFile = FileNameJoin[{$QuadrupleOutDir, quadTag <> ".txt"}];
  readable = If[Length[sols] == 0,
    "No spectra.",
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum4[#1, repData] &, sols], "\n"]
  ];
  Export[txtFile, readable, "Text"];
];

appendCountCSV4[row_Association, csvFile_] := Module[{header, line},
  header = "quadruple_index,group1,group2,group3,group4,dimG1,dimG2,dimG3,dimG4,M_drone,count\n";
  If[! FileExistsQ[csvFile], Export[csvFile, header, "Text"]];
  line = StringRiffle[ToString /@ Lookup[row, {"quadruple_index", "group1", "group2", "group3", "group4", "dimG1", "dimG2", "dimG3", "dimG4", "M_drone", "count"}], ","] <> "\n";
  WriteString[csvFile, line]
];

(* ---------------------------------------------------------------------- *)
(* Driver                                                                 *)
(* ---------------------------------------------------------------------- *)

allGroupQuadruples[groups_List] := Module[{sorted, quads},
  sorted = SortBy[groups, groupSortKey];
  quads = Flatten[
    Table[{sorted[[i]], sorted[[j]], sorted[[k]], sorted[[l]]},
      {i, Length[sorted]}, {j, i, Length[sorted]}, {k, j, Length[sorted]}, {l, k, Length[sorted]}],
    3
  ];
  If[TrueQ[$ReverseGroupQuadrupleOrder], Reverse[quads], quads]
];

droneCountForGroupList[groupList_List, repData_] := $dimNonRMax - Total[(repData[#]["DimG"] &) /@ groupList];

pruneNegativeDroneQuadruples[quads_List, repData_] := Module[{kept, deleted},
  If[! TrueQ[$PruneNegativeDroneQuadruplesAtStart], Return[quads]];
  kept = Select[quads, droneCountForGroupList[#, repData] >= 0 &];
  deleted = Length[quads] - Length[kept];
  If[deleted > 0, Print["Pruned ", deleted, " group quadruples with negative drone count before scanning."]];
  kept
];

filterQuadruplesByUserChoice[quads_List] := Module[{q = quads, only},
  only = $OnlyGroupQuadruples;
  If[only =!= All,
    q = Select[q, MemberQ[only, #] &]
  ];
  q = Take[q, {Max[1, $StartQuadrupleIndex], Min[Length[q], $EndQuadrupleIndex]}];
  q
];

shadowTargets14to34[n3sp_Association, b4_List, groups_List, repData_] := Module[{lams = (repData[#]["Lambda"] &) /@ groups, branches},
  branches = Join[n3sp["Branches"], {b4}];
  Together[Table[etaDot[branches[[i]], b4]/(lams[[i]] lams[[4]]), {i, 3}]]
];

scanOneGroupQuadruple[quadIndex_, quad_List, n3ByTriple_, n1ByGB_, repData_] := Module[
  {g1 = quad[[1]], g2 = quad[[2]], g3 = quad[[3]], g4 = quad[[4]], dims, mDrone, quadTag,
   n3Key, n3List, branches4, candidatePairs, activePairs, uniqueBranchPairs, activeUniqueBranchPairs,
   totalCases, caseCounter = 0, printProgressQ, t0, sols = {}, partial, b4, n1List, row},

  dims = (repData[#]["DimG"] &) /@ quad;
  mDrone = $dimNonRMax - Total[dims];
  quadTag = StringPadLeft[ToString[quadIndex], 4, "0"] <> "_" <> StringRiffle[quad, "x"];
  Print["\nScanning quadruple ", quadIndex, ": ", StringRiffle[quad, " x "], "   M_drone = ", mDrone];

  If[TrueQ[$RequireNonnegativeDroneCount] && mDrone < 0,
    Print["  skipped: negative drone count."];
    writeQuadrupleOutput[quadTag, {}, repData];
    Return[<|"quadruple_index" -> quadIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3, "group4" -> g4,
      "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "dimG4" -> dims[[4]], "M_drone" -> mDrone, "count" -> 0|>]
  ];

  n3Key = {g1, g2, g3};
  n3List = If[KeyExistsQ[n3ByTriple, n3Key], n3ByTriple[n3Key], {}];
  If[Length[n3List] > 0 && ! AllTrue[n3List, validN3SpectrumBlockQ],
    Print["  ERROR: the n = 3 lookup for ", StringRiffle[n3Key, " x "], " did not return a flat list of spectrum associations."];
    Print["  Internal n3 key = ", n3Key, "; Head[n3List] = ", Head[n3List], "; Head[First[n3List]] = ", Head[First[n3List]]];
    Abort[]
  ];
  If[Length[n3List] == 0 || ! KeyExistsQ[n1ByGB, g4],
    Print["  skipped: missing n = 3 block or n = 1 data."];
    writeQuadrupleOutput[quadTag, {}, repData];
    Return[<|"quadruple_index" -> quadIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3, "group4" -> g4,
      "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "dimG4" -> dims[[4]], "M_drone" -> mDrone, "count" -> 0|>]
  ];

  branches4 = Keys[n1ByGB[g4]];
  Print["  n = 3 spectra for ", StringRiffle[n3Key, " x "], ": ", Length[n3List]];
  Print["  n = 3 branch-triple counts: ", Counts[(# ["Branches"] &) /@ n3List]];
  Print["  branch count for ", g4, ": ", Length[branches4], "   branches = ", branches4];

  candidatePairs = Flatten[Table[{n3sp, b4}, {n3sp, n3List}, {b4, branches4}], 1];

  uniqueBranchPairs = DeleteDuplicatesBy[candidatePairs, {#[[1]]["Branches"], #[[2]]} &];
  activeUniqueBranchPairs = Select[uniqueBranchPairs,
    vectorNonnegativeQ[shadowTargets14to34[# [[1]], # [[2]], quad, repData]] &
  ];

  activePairs = Select[candidatePairs,
    vectorNonnegativeQ[shadowTargets14to34[# [[1]], # [[2]], quad, repData]] &
  ];
  Print["  active unique branch quadruples {b1,b2,b3,b4} with nonnegative targets: ",
    Length[activeUniqueBranchPairs], " / ", Length[uniqueBranchPairs]];
  Print["  active n3-spectrum/shadow-branch candidates with nonnegative targets: ",
    Length[activePairs], " / ", Length[candidatePairs]];
  If[TrueQ[$PrintKeyDiagnostics] && Length[uniqueBranchPairs] > 0,
    Print["  sample unique-branch shadow targets {T14,T24,T34}: ",
      Take[(<|"b123" -> #[[1]]["Branches"], "b4" -> #[[2]],
          "target" -> shadowTargets14to34[#[[1]], #[[2]], quad, repData]|> &) /@ uniqueBranchPairs, UpTo[5]]]
  ];

  totalCases = Total[Length[n1ByGB[g4][# [[2]]]] & /@ activePairs];
  Print["  n3/n1 concrete spectrum pairs to scan: ", totalCases];

  printProgressQ[k_Integer] := TrueQ[$PrintQuadrupleScanProgress] && totalCases > 0 && (k == 1 || k == totalCases || Mod[k - 1, $QuadrupleScanProgressEvery] == 0);
  t0 = AbsoluteTime[];

  Do[
    b4 = ap[[2]];
    n1List = n1ByGB[g4][b4];
    Do[
      caseCounter++;
      If[printProgressQ[caseCounter],
        Print["  ", caseCounter, "/", totalCases,
          "   elapsed=", NumberForm[AbsoluteTime[] - t0, {Infinity, 1}], "s",
          "   b123=", ap[[1]]["Branches"], " b4=", b4,
          "   n1 ID4=", n1sp["ID"]]
      ];
      partial = assembleFromN3AndN1[ap[[1]], n1sp, repData];
      If[Length[partial] > 0, sols = Join[sols, partial]];
      ,
      {n1sp, n1List}
    ];
    ,
    {ap, activePairs}
  ];

  sols = DeleteDuplicatesBy[sols, solutionKey4];
  Print["  finished ", StringRiffle[quad, " x "], ": ", Length[sols], " spectra."];
  writeQuadrupleOutput[quadTag, sols, repData];
  row = <|"quadruple_index" -> quadIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3, "group4" -> g4,
    "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "dimG4" -> dims[[4]], "M_drone" -> mDrone,
    "count" -> Length[sols], "Solutions" -> sols|>;
  row
];

RunN4GTSA[] := Module[
  {repData, n1, n1Good, n3, n3Good, groups, quads, n1ByGB, n3ByTriple,
   countsFile, allCounts = {}, allSolutions = {}, row},

  If[! DirectoryQ[$OutDir], CreateDirectory[$OutDir, CreateIntermediateDirectories -> True]];
  If[! DirectoryQ[$QuadrupleOutDir], CreateDirectory[$QuadrupleOutDir, CreateIntermediateDirectories -> True]];
  If[TrueQ[$CleanQuadrupleOutputFolderToTextOnly],
    Quiet[DeleteFile /@ Select[FileNames["*", $QuadrupleOutDir], FileType[#] === File && MemberQ[{"wl", "wxf"}, ToLowerCase[FileExtension[#]]] &]]
  ];

  countsFile = FileNameJoin[{$OutDir, "n4_GTSA_quadruple_counts.csv"}];
  Quiet[If[FileExistsQ[countsFile], DeleteFile[countsFile]], DeleteFile::fdnfnd];

  Print["Loading representation data from ", $RepInfoFile];
  repData = loadRepData[$RepInfoFile];
  Print["Loaded groups: ", StringRiffle[Keys[repData], ", "]];

  Print["Parsing final n = 1 catalogue from ", $N1CataloguePDF];
  n1 = parseN1Catalogue[$N1CataloguePDF, repData];
  If[IntegerQ[$ExpectedN1SpectrumCount] && Length[n1] =!= $ExpectedN1SpectrumCount,
    Print["Expected ", $ExpectedN1SpectrumCount, " n = 1 spectra, but parsed ", Length[n1], "."];
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n1Good = Select[n1,
    (# ["OneFactorChecks"]["quarticBResidual"] === 0 && # ["OneFactorChecks"]["extraDResidual"] === 0 &&
      # ["OneFactorChecks"]["normActual"] === # ["OneFactorChecks"]["normRequired"]) &
  ];
  If[TrueQ[$RequireIntegralAnomalyVectors], n1Good = Select[n1Good, latticeAdmissibleQ[# ["Branch"]] &]];
  Print["One-factor spectra kept for n = 4 scan after the I_{1,1} lattice test: ", Length[n1Good]];

  Print["Loading n = 3 spectra from ", $N3SpectraWL];
  n3 = loadN3Spectra[$N3SpectraWL];
  If[IntegerQ[$ExpectedN3SpectrumCount] && Length[n3] =!= $ExpectedN3SpectrumCount,
    Print["Expected ", $ExpectedN3SpectrumCount, " n = 3 spectra, but loaded ", Length[n3], "."];
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n3 = MapIndexed[If[KeyExistsQ[#1, "SpectrumID"], #1, Join[#1, <|"SpectrumID" -> #2[[1]]|>]] &, n3];
  If[TrueQ[$CheckN3SourceAgainstN1] && ! TrueQ[validateN3AgainstN1[n3, n1]],
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n3Good = n3;
  If[TrueQ[$CheckN3InputLocalPass],
    n3Good = Select[n3Good, TrueQ[Lookup[Lookup[#, "LocalCheck", <||>], "Pass", False]] &];
    Print["n = 3 spectra with LocalCheck[Pass] kept: ", Length[n3Good]];
    If[Length[n3Good] < Length[n3] && TrueQ[$AbortOnBadInput],
      Print["Some n = 3 spectra failed/missed LocalCheck[Pass]. Set $AbortOnBadInput=False to continue."];
      Abort[]
    ];
  ];
  If[TrueQ[$CheckN3BranchLattice],
    Module[{badN3Lattice = Select[n3Good, ! n3BranchesLatticeAdmissibleQ[#] &]},
      If[Length[badN3Lattice] > 0,
        Print["Found ", Length[badN3Lattice], " n = 3 spectra with branch vectors outside the displayed I_{1,1} lattice."];
        Print["First bad branch triples: ", Take[(# ["Branches"] &) /@ badN3Lattice, UpTo[10]]];
        If[TrueQ[$AbortOnBadInput], Abort[], n3Good = Complement[n3Good, badN3Lattice]]
      ];
    ]
  ];

  groups = SortBy[Union[Keys[GroupBy[n1Good, # ["Group"] &]], Flatten[(# ["Groups"] &) /@ n3Good]], groupSortKey];
  quads = allGroupQuadruples[groups];
  Print["Raw gauge-group quadruples before drone pruning: ", Length[quads]];
  quads = pruneNegativeDroneQuadruples[quads, repData];
  quads = filterQuadruplesByUserChoice[quads];
  Print["Gauge-group quadruples to scan: ", Length[quads]];

  n1ByGB = GroupBy[n1Good, {# ["Group"] &, # ["Branch"] &}];
  (* Important: this is a single key {Group1,Group2,Group3}, not nested GroupBy. *)
  n3ByTriple = GroupBy[n3Good, # ["Groups"] &];
  (* IMPORTANT: list-valued triple keys must be read by assoc[key], not by Lookup[assoc,key,...]. *)
  If[TrueQ[$PrintKeyDiagnostics],
    Print["n = 3 triple keys loaded: ", Length[Keys[n3ByTriple]]];
    If[KeyExistsQ[n3ByTriple, {"A3", "A3", "A3"}],
      Print["Diagnostic A3 x A3 x A3 n = 3 spectra: ", Length[n3ByTriple[{"A3", "A3", "A3"}]],
        "; branch-triple counts: ", Counts[(# ["Branches"] &) /@ n3ByTriple[{"A3", "A3", "A3"}]]]
    ];
  ];

  Do[
    row = scanOneGroupQuadruple[i, quads[[i]], n3ByTriple, n1ByGB, repData];
    AppendTo[allCounts, KeyDrop[row, "Solutions"]];
    allSolutions = DeleteDuplicatesBy[Join[allSolutions, Lookup[row, "Solutions", {}]], solutionKey4];
    Print["  quadruple summary: ", StringRiffle[quads[[i]], " x "],
      " has ", row["count"], " spectra; total so far = ", Length[allSolutions], "."];
    appendCountCSV4[KeyDrop[row, "Solutions"], countsFile];
    Export[FileNameJoin[{$OutDir, "n4_GTSA_all_spectra_so_far.wxf"}], allSolutions, "WXF"];
    Put[allSolutions, FileNameJoin[{$OutDir, "n4_GTSA_all_spectra_so_far.wl"}]];
    ,
    {i, Length[quads]}
  ];

  allSolutions = DeleteDuplicatesBy[allSolutions, solutionKey4];
  Export[FileNameJoin[{$OutDir, "n4_GTSA_all_spectra.wxf"}], allSolutions, "WXF"];
  Put[allSolutions, FileNameJoin[{$OutDir, "n4_GTSA_all_spectra.wl"}]];
  Export[FileNameJoin[{$OutDir, "n4_GTSA_all_spectra_readable.txt"}],
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum4[#1, repData] &, allSolutions], "\n"],
    "Text"
  ];
  Export[FileNameJoin[{$OutDir, "n4_GTSA_quadruple_counts_final.csv"}], Normal /@ allCounts];

  If[TrueQ[$DeleteTemporaryFilesAfterFullScan],
    Quiet[DeleteFile /@ Select[{
      FileNameJoin[{$OutDir, "n4_GTSA_all_spectra_so_far.wl"}],
      FileNameJoin[{$OutDir, "n4_GTSA_all_spectra_so_far.wxf"}],
      countsFile
    }, FileExistsQ]];
    Print["Temporary checkpoint files deleted after successful full scan."]
  ];

  Print["\nFull n = 4 scan finished. Total spectra: ", Length[allSolutions]];
  <|"Counts" -> allCounts, "Solutions" -> allSolutions, "RepData" -> repData|>
];

If[TrueQ[$RunNow], RunN4GTSA[]];
