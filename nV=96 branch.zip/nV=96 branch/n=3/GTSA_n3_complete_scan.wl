(* ::Package:: *)
(*
  GTSA_n3_complete_scan_NEW_CONVENTION_20260715.wl

  n = 3 GTSA scan for the n_V = 96 Sp(1)_R branch.

  Inputs, by default:
    C:\Physics\6d anomaly free models\n=3\RepInfo.nb
    C:\Physics\6d anomaly free models\n=3\n1_Sp1R_Catalogue.pdf
    C:\Physics\6d anomaly free models\n=3\n2_GTSA_all_spectra.wl

  Main implementation choices:
    - Uses eta=((0,1),(1,0)), a=(-2,-2), and b_R=(3/2,-5).
    - Uses final n = 2 spectra as the two-factor shadow block and final n = 1 spectra as the third factor.
    - Recomputes every n = 1 branch from RepInfo.nb and checks it against the vector printed in n1_Sp1R_Catalogue.pdf.
    - Cross-checks the n = 2 source IDs, gauge groups, and branch vectors against the n = 1 catalogue before scanning.
    - Scans unordered triples G1 <= G2 <= G3 with dim(G1)+dim(G2)+dim(G3) <= 93.
    - For each candidate, it lifts two-factor matter (R1,R2) and one-factor matter R3
      into three-factor matter (R1,R2,R3).
    - Every pairwise mixed anomaly is checked against the shadow pairing:
          sum_H A_i(R_i) A_j(R_j) prod_{k != i,j} dim(R_k) == b_i.b_j/(lambda_i lambda_j).
    - The full local anomaly matrix in basis
          (tr R^2, tr_2 F_R^2, tr F_1^2, tr F_2^2, tr F_3^2)
      is recomputed and must have rank <= 2.
    - Half-integer multiplicities are allowed only when the full product representation is pseudoreal.
      PS = 1/2 means pseudoreal.  PS = 1 is split into real/complex using Dynkin conjugation.
    - Duplicate spectra under permutations of identical simple factors are quotiented by a canonical key.
    - Pair/triple output folder receives readable .txt files only; final WL/WXF/TXT/CSV are written at the end.
*)

ClearAll["Global`*"];

(* ---------------------------------------------------------------------- *)
(* User settings                                                          *)
(* ---------------------------------------------------------------------- *)

$GTSAN3ScanVersion = "new-offdiag-convention-n1-n2-crosscheck-v1-20260715";

If[! ValueQ[$BaseDir], $BaseDir = "C:\\Physics\\6d anomaly free models\\n=3"];
If[! ValueQ[$RepInfoFile], $RepInfoFile = FileNameJoin[{$BaseDir, "RepInfo.nb"}]];
If[! ValueQ[$N1CataloguePDF], $N1CataloguePDF = FileNameJoin[{$BaseDir, "n1_Sp1R_Catalogue.pdf"}]];
If[! ValueQ[$N2SpectraWL], $N2SpectraWL = FileNameJoin[{$BaseDir, "n2_GTSA_all_spectra.wl"}]];

If[! ValueQ[$OutDir], $OutDir = FileNameJoin[{$BaseDir, "n3_GTSA_complete_outputs"}]];
If[! ValueQ[$TripleOutDir], $TripleOutDir = FileNameJoin[{$OutDir, "triple_outputs"}]];

If[! ValueQ[$ReverseGroupTripleOrder], $ReverseGroupTripleOrder = False];
If[! ValueQ[$RequireIntegralAnomalyVectors], $RequireIntegralAnomalyVectors = True];
If[! ValueQ[$RequireNonnegativeDroneCount], $RequireNonnegativeDroneCount = True];
If[! ValueQ[$PruneNegativeDroneTriplesAtStart], $PruneNegativeDroneTriplesAtStart = True];
If[! ValueQ[$QuotientIdenticalFactorPermutation], $QuotientIdenticalFactorPermutation = True];
If[! ValueQ[$CleanTripleOutputFolderToTextOnly], $CleanTripleOutputFolderToTextOnly = True];
If[! ValueQ[$DeleteTemporaryFilesAfterFullScan], $DeleteTemporaryFilesAfterFullScan = True];
If[! ValueQ[$RunNow], $RunNow = True];

(* Progress inside each fixed group triple. *)
If[! ValueQ[$PrintTripleScanProgress], $PrintTripleScanProgress = True];
If[! ValueQ[$TripleScanProgressEvery], $TripleScanProgressEvery = 1000];
If[! ValueQ[$PrintPairKeyDiagnostics], $PrintPairKeyDiagnostics = True];

(* Safety/debug switches. *)
If[! ValueQ[$CheckN2InputLocalPass], $CheckN2InputLocalPass = True];
If[! ValueQ[$CheckN2SourceIDsAgainstN1], $CheckN2SourceIDsAgainstN1 = True];
If[! ValueQ[$CheckN2BranchLattice], $CheckN2BranchLattice = True];
If[! ValueQ[$ExpectedN1SpectrumCount], $ExpectedN1SpectrumCount = 652];
If[! ValueQ[$ExpectedN2SpectrumCount], $ExpectedN2SpectrumCount = 1968];
If[! ValueQ[$AbortOnBadInput], $AbortOnBadInput = True];

$nV = 96;
$nH = $nV + 244;
$dimNonRMax = $nV - 3;   (* 93 = 96 - dim Sp(1)_R *)

(* Off-diagonal coordinate convention used in the revised n_V = 96 catalogues. *)
$aVec = {-2, -2};
$bRVec = {3/2, -5};

(* ---------------------------------------------------------------------- *)
(* General utilities                                                      *)
(* ---------------------------------------------------------------------- *)

etaDot[u_List, v_List] := u[[1]] v[[2]] + u[[2]] v[[1]];
etaNorm[u_List] := etaDot[u, u];
innerRow[u_List] := {u[[2]], u[[1]]};

(* In these displayed off-diagonal coordinates, the integral odd I_{1,1}
   lattice is the image of Z^2 under (m,n) -> ((m+n)/2,m-n). *)
latticeAdmissibleQ[v_List] := Module[{twox = Together[2 v[[1]]], y = Together[v[[2]]]},
  IntegerQ[twox] && IntegerQ[y] && EvenQ[twox - y]
];

safeName[s_String] := StringReplace[s, Except[WordCharacter] -> "_"];
vecKey[v_List] := ToString[InputForm[v]];

positiveAssoc[a_Association] := Association @ KeyValueMap[If[#2 === 0, Nothing, #1 -> #2] &, a];

formatRational[x_] := Which[
  IntegerQ[x], ToString[x],
  Denominator[x] == 2 && Numerator[x] == 1, "1/2",
  Denominator[x] == 2, ToString[Numerator[x]] <> "/2",
  True, ToString[InputForm[x]]
];
formatMult[x_] := If[x === 1, "", formatRational[x] <> " x "];

ratRange[max_, step_] := Table[i step, {i, 0, Floor[max/step]}];

subtractAssoc[a_Association, key_, amount_] := Module[{val},
  val = assocGet[a, key, 0] - amount;
  If[val < 0, Return[$Failed]];
  If[val === 0, assocDropKey[a, key], assocPut[a, key, val]]
];

vectorNonnegativeQ[v_List] := AllTrue[v, TrueQ[# >= 0] &];

(* Association helpers for keys that are themselves lists, e.g. {Rep1,Rep2}.
   Lookup[assoc, {a,b}, def] means lookup two separate keys a and b, not the
   composite key {a,b}.  Therefore composite keys must be accessed by assoc[key]
   after KeyExistsQ, and dropped as a one-element key list {key}. *)
assocGet[a_Association, key_, default_:0] := If[KeyExistsQ[a, key], a[key], default];
assocDropKey[a_Association, key_] := KeyDrop[a, {key}];
assocPut[a_Association, key_, value_] := Association[assocDropKey[a, key], key -> value];

(* ---------------------------------------------------------------------- *)
(* Lie-group conventions                                                  *)
(* ---------------------------------------------------------------------- *)

groupType[g_String] := StringTake[g, 1];
groupRank[g_String] := ToExpression[StringDrop[g, 1]];

groupSortKey[g_String] := {Switch[groupType[g], "A", 1, "B", 2, "C", 3, "D", 4, "E", 5, "F", 6, "G", 7, _, 99], groupRank[g]};

lambdaFactor[g_String] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", 1,
    "B", 2,
    "C", 1,
    "D", 2,
    "E", Switch[n, 6, 6, 7, 12, 8, 60, _, Missing["UnknownLambda", g]],
    "F", 6,
    "G", 2,
    _, Missing["UnknownLambda", g]
  ]
];

normalizeGroupName[Subscript[s_, n_Integer]] := ToUpperCase[StringTake[SymbolName[Unevaluated[s]], 1]] <> ToString[n];
normalizeGroupName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {
    "Subscript[a, " ~~ n : DigitCharacter.. ~~ "]" :> "A" <> n,
    "Subscript[b, " ~~ n : DigitCharacter.. ~~ "]" :> "B" <> n,
    "Subscript[c, " ~~ n : DigitCharacter.. ~~ "]" :> "C" <> n,
    "Subscript[d, " ~~ n : DigitCharacter.. ~~ "]" :> "D" <> n,
    "Subscript[e, " ~~ n : DigitCharacter.. ~~ "]" :> "E" <> n,
    "Subscript[f, " ~~ n : DigitCharacter.. ~~ "]" :> "F" <> n,
    "Subscript[g, " ~~ n : DigitCharacter.. ~~ "]" :> "G" <> n
  }]
];

normalizeRepName[Subscript[r_, n_Integer]] := "r" <> ToString[n];
normalizeRepName[s_Symbol] := SymbolName[Unevaluated[s]];
normalizeRepName[x_] := Module[{y = ToString[Unevaluated[x], InputForm]},
  StringReplace[y, {"Subscript[r, " ~~ n : DigitCharacter.. ~~ "]" :> "r" <> n}]
];

(* Dynkin-label conjugation.  PS == 1 is not enough: A_n, D_odd and E6 can be complex. *)
conjugateDynkin[g_String, dyn_List] := Module[{t = groupType[g], n = groupRank[g]},
  Switch[t,
    "A", Reverse[dyn],
    "D", If[OddQ[n], ReplacePart[dyn, {n - 1 -> dyn[[n]], n -> dyn[[n - 1]]}], dyn],
    "E", If[n == 6, dyn[[{5, 4, 3, 2, 1, 6}]], dyn],
    _, dyn
  ]
];

realityType[g_String, ps_, dyn_List] := Which[
  ps === 1/2, "Pseudoreal",
  ps === Rational[1, 2], "Pseudoreal",
  conjugateDynkin[g, dyn] === dyn, "Real",
  True, "Complex"
];

productRealityFromReps[repList_List] := Module[{types, prCount},
  types = repList[[All, "Reality"]];
  If[MemberQ[types, "Complex"], Return["Complex"]];
  prCount = Count[types, "Pseudoreal"];
  If[OddQ[prCount], "Pseudoreal", "Real"]
];

productPseudoRealQ[repList_List] := productRealityFromReps[repList] === "Pseudoreal";

allowedProductMultiplicityQ[m_, repList_List] := IntegerQ[m] || (productPseudoRealQ[repList] && IntegerQ[2 m]);

(* ---------------------------------------------------------------------- *)
(* Load RepInfo.nb                                                        *)
(* ---------------------------------------------------------------------- *)

loadNotebookInputs[file_] := Module[{inputs},
  Clear[reps];
  inputs = Quiet @ Check[NotebookImport[file, "Input"], $Failed];
  If[inputs === $Failed, inputs = Quiet @ Check[NotebookImport[file, "InputText"], $Failed]];
  If[inputs === $Failed,
    Print["Could not import input cells from ", file]; Abort[]
  ];
  Scan[
    Function[expr,
      Quiet @ Check[ReleaseHold[expr], Null];
      If[! ValueQ[reps], Quiet @ Check[ToExpression[ToString[Unevaluated[expr], InputForm]], Null]];
      If[StringQ[expr] && ! ValueQ[reps], Quiet @ Check[ToExpression[expr], Null]];
    ],
    Flatten[{inputs}]
  ];
  If[! ValueQ[reps], Print["The symbol reps was not defined after reading ", file]; Abort[]];
  reps
];

buildRepData[repRules_] := Association @ Map[
  Function[grule,
    Module[{g, raw, repAssoc},
      g = normalizeGroupName[grule[[1]]];
      raw = grule[[2]];
      repAssoc = Association @ MapIndexed[
        Function[{rr, idx},
          Module[{nm, coeffs, dyn, dimv, ps},
            nm = normalizeRepName[rr[[1]]];
            coeffs = Association[rr[[2]]];
            dyn = Lookup[coeffs, dynkin];
            dimv = Lookup[coeffs, dim];
            ps = Lookup[coeffs, PS];
            nm -> <|
              "Name" -> nm,
              "Index" -> idx[[1]],
              "Dynkin" -> dyn,
              "Dim" -> dimv,
              "PS" -> ps,
              "Reality" -> realityType[g, ps, dyn],
              "QuarticB" -> Lookup[coeffs, Global`a],
              "QuadC" -> Lookup[coeffs, Global`b],
              "IndexA" -> Lookup[coeffs, Global`c],
              "ExtraD" -> Lookup[coeffs, Global`d]
            |>
          ]
        ],
        raw
      ];
      g -> <|
        "Group" -> g,
        "Rank" -> groupRank[g],
        "Lambda" -> lambdaFactor[g],
        "Reps" -> repAssoc,
        "DimG" -> repAssoc["adj"]["Dim"]
      |>
    ]
  ],
  repRules
];

loadRepData[file_] := buildRepData[loadNotebookInputs[file]];

(* ---------------------------------------------------------------------- *)
(* Parse n = 1 catalogue                                                  *)
(* ---------------------------------------------------------------------- *)

findRepByDynkinDim[repData_, g_String, dyn_List, dimv_Integer] := Module[{lst, hit},
  lst = Values[repData[g]["Reps"]];
  hit = Select[lst, (# ["Dynkin"] === dyn && # ["Dim"] === dimv) &];
  If[Length[hit] != 1,
    Print["Could not uniquely match representation in ", g, ": dynkin=", dyn, ", dim=", dimv, "; matches=", Length[hit]];
    Abort[]
  ];
  First[hit]
];

parseSpectrumTerms[spec_String, g_String, repData_] := Module[{termRE, rawTerms},
  termRE = RegularExpression["(\\d+)\\s*x\\s*\\(([^\\)]*)\\)\\s*(\\d+)\\s*(half)?"];
  rawTerms = StringCases[spec, termRE -> {"$1", "$2", "$3", "$4"}];
  Map[
    Function[t,
      Module[{m0, dyn, dimv, half, rep, mult},
        m0 = ToExpression[t[[1]]];
        dyn = ToExpression["{" <> StringReplace[t[[2]], WhitespaceCharacter .. -> ""] <> "}"];
        dimv = ToExpression[t[[3]]];
        half = StringTrim[t[[4]]] === "half";
        rep = findRepByDynkinDim[repData, g, dyn, dimv];
        mult = If[half, m0/2, m0];
        If[! allowedProductMultiplicityQ[mult, {rep}],
          Print["Bad one-factor multiplicity in PDF for ", g, ": ", mult, " x ", rep["Name"], " has reality ", rep["Reality"]];
          Abort[]
        ];
        <|"Rep" -> rep["Name"], "Mult" -> mult|>
      ]
    ],
    rawTerms
  ]
];

repAssocFromN1Entries[entries_List] := Merge[(# ["Rep"] -> # ["Mult"]) & /@ entries, Total];

spectrumSumsOneFactor[sp_Association, repData_] := Module[{g = sp["Group"], reps, entries},
  reps = repData[g]["Reps"];
  entries = sp["Entries"];
  <|
    "IndexA" -> Total[(# ["Mult"] reps[# ["Rep"]]["IndexA"]) & /@ entries],
    "QuadC" -> Total[(# ["Mult"] reps[# ["Rep"]]["QuadC"]) & /@ entries],
    "QuarticB" -> Total[(# ["Mult"] reps[# ["Rep"]]["QuarticB"]) & /@ entries],
    "ExtraD" -> Total[(# ["Mult"] reps[# ["Rep"]]["ExtraD"]) & /@ entries]
  |>
];

deriveBranchVector[sp_Association, repData_] := Module[
  {g = sp["Group"], lam, adj, sums, dotA, dotR, mat, vec, normReq, checks},
  lam = repData[g]["Lambda"];
  adj = repData[g]["Reps"]["adj"];
  sums = spectrumSumsOneFactor[sp, repData];
  dotA = lam/6 (adj["IndexA"] - sums["IndexA"]);
  dotR = -lam adj["IndexA"]/2;
  mat = {innerRow[$aVec], innerRow[$bRVec]};
  vec = Together[LinearSolve[mat, {dotA, dotR}]];
  normReq = lam^2/3 (sums["QuadC"] - adj["QuadC"]);
  checks = <|
    "aDot" -> dotA,
    "bRDot" -> dotR,
    "normRequired" -> Together[normReq],
    "normActual" -> Together[etaNorm[vec]],
    "quarticBResidual" -> Together[adj["QuarticB"] - sums["QuarticB"]],
    "extraDResidual" -> Together[adj["ExtraD"] - sums["ExtraD"]]
  |>;
  {vec, checks}
];

parseN1Catalogue[pdfFile_, repData_] := Module[
  {txt, clean, groups, headers, blocks, rowRE, spectra},
  If[! FileExistsQ[pdfFile], Print["n = 1 catalogue not found: ", pdfFile]; Abort[]];
  txt = Import[pdfFile, "Plaintext"];
  clean = StringReplace[txt, {"\r" -> " ", "\n" -> " ", WhitespaceCharacter .. -> " "}];
  groups = Keys[repData];
  headers = SortBy[
    Flatten[
      Table[(Append[#, g] & /@ StringPosition[clean, g <> " spectra"]), {g, groups}],
      1
    ],
    First
  ];
  headers = DeleteDuplicatesBy[headers, {# [[1]], # [[3]]} &];
  blocks = Table[
    Module[{start = headers[[i, 2]] + 1, stop, g = headers[[i, 3]]},
      stop = If[i < Length[headers], headers[[i + 1, 1]] - 1, StringLength[clean]];
      {g, StringTake[clean, {start, stop}]}
    ],
    {i, Length[headers]}
  ];

  (* Revised n=1 rows have the form
       ID  (b_x,b_y)  singlets  H_charged  charged spectrum.
     The branch displayed in the PDF is checked against an independent
     recomputation from RepInfo.nb. *)
  rowRE = RegularExpression[
    "(\\d+)\\s+\\(\\s*(-?\\d+(?:/\\d+)?)\\s*,\\s*(-?\\d+(?:/\\d+)?)\\s*\\)\\s+" <>
    "(\\d+)\\s+(\\d+)\\s+(.*?)(?=(?:\\s\\d+\\s+\\(\\s*-?\\d+(?:/\\d+)?\\s*,\\s*-?\\d+(?:/\\d+)?\\s*\\)\\s+\\d+\\s+\\d+\\s+)|$)"
  ];
  spectra = Flatten[
    Map[
      Function[blk,
        Module[{g = blk[[1]], block = blk[[2]], rows},
          rows = StringCases[block, rowRE -> {"$1", "$2", "$3", "$4", "$5", "$6"}];
          Map[
            Function[r,
              Module[{sp, br, shownBr, checks},
                shownBr = ToExpression /@ r[[{2, 3}]];
                sp = <|
                  "ID" -> ToExpression[r[[1]]],
                  "Group" -> g,
                  "Singlets" -> ToExpression[r[[4]]],
                  "HCharged" -> ToExpression[r[[5]]],
                  "Entries" -> parseSpectrumTerms[r[[6]], g, repData]
                |>;
                {br, checks} = deriveBranchVector[sp, repData];
                If[br =!= shownBr,
                  Print["Displayed/recomputed branch mismatch for n=1 ID ", sp["ID"],
                    ": displayed=", shownBr, ", recomputed=", br];
                  Abort[]
                ];
                Join[sp, <|"Branch" -> br, "OneFactorChecks" -> checks|>]
              ]
            ],
            rows
          ]
        ]
      ],
      blocks
    ],
    1
  ];
  Print["Parsed ", Length[spectra], " one-factor spectra from ", pdfFile];
  spectra
];

(* ---------------------------------------------------------------------- *)
(* Load/check n = 2 spectra                                               *)
(* ---------------------------------------------------------------------- *)

loadN2Spectra[file_] := Module[{data},
  If[! FileExistsQ[file], Print["n = 2 spectrum file not found: ", file]; Abort[]];
  data = Get[file];
  If[! ListQ[data], Print["n = 2 file did not evaluate to a list: ", file]; Abort[]];
  Print["Loaded ", Length[data], " n = 2 spectra from ", file];
  data
];


validateN2AgainstN1[n2_List, n1_List] := Module[{n1ByID, bad},
  n1ByID = Association[(# ["ID"] -> #) & /@ n1];
  bad = Select[n2,
    Module[{id1, id2, s1, s2},
      id1 = Lookup[#, "N1ID1", Missing["N1ID1"]];
      id2 = Lookup[#, "N1ID2", Missing["N1ID2"]];
      If[! KeyExistsQ[n1ByID, id1] || ! KeyExistsQ[n1ByID, id2], Return[True]];
      s1 = n1ByID[id1]; s2 = n1ByID[id2];
      !(s1["Group"] === #["Group1"] && s2["Group"] === #["Group2"] &&
        s1["Branch"] === #["Branch1"] && s2["Branch"] === #["Branch2"])
    ] &
  ];
  If[Length[bad] > 0,
    Print["Found ", Length[bad], " n = 2 spectra whose source n = 1 IDs/groups/branches do not match the catalogue."];
    Print["First mismatches: ", Take[bad, UpTo[5]]];
    False,
    Print["All n = 2 source IDs, groups, and branch vectors agree with the n = 1 catalogue."];
    True
  ]
];

n2BranchesLatticeAdmissibleQ[sp_Association] :=
  latticeAdmissibleQ[sp["Branch1"]] && latticeAdmissibleQ[sp["Branch2"]];

n2SpectrumKeyForGrouping[sp_Association] := {sp["Group1"], sp["Group2"]};

repAssocFromN2Entries[entries_List] := Merge[({# ["Rep1"], # ["Rep2"]} -> # ["Mult"]) & /@ entries, Total];

(* ---------------------------------------------------------------------- *)
(* Product-representation helpers                                         *)
(* ---------------------------------------------------------------------- *)

repDataForKey12[key_List, g1_, g2_, repData_] := {repData[g1]["Reps"][key[[1]]], repData[g2]["Reps"][key[[2]]]};
repDataForKey123[key_List, groups_List, repData_] := MapThread[repData[#1]["Reps"][#2] &, {groups, key}];

allowedLeftover12Q[rem12_Association, g1_, g2_, repData_] := AllTrue[Normal[rem12], allowedProductMultiplicityQ[# [[2]], repDataForKey12[# [[1]], g1, g2, repData]] &];
allowedLeftover1Q[rem1_Association, g_, repData_] := AllTrue[Normal[rem1], allowedProductMultiplicityQ[# [[2]], {repData[g]["Reps"][# [[1]]]}] &];
allowedTripleMultiplicityQ[m_, r1_, r2_, r3_] := allowedProductMultiplicityQ[m, {r1, r2, r3}];

(* ---------------------------------------------------------------------- *)
(* Build/check n = 3 spectra                                              *)
(* ---------------------------------------------------------------------- *)

buildEntriesFromState3[g1_, g2_, g3_, rem12_, rem3_, links_] := Module[{left12, left3, linkEntries},
  left12 = KeyValueMap[<|"Rep1" -> #1[[1]], "Rep2" -> #1[[2]], "Rep3" -> "r0", "Mult" -> #2|> &, rem12];
  left3 = KeyValueMap[<|"Rep1" -> "r0", "Rep2" -> "r0", "Rep3" -> #1, "Mult" -> #2|> &, rem3];
  linkEntries = Map[<|"Rep1" -> #[[1, 1]], "Rep2" -> #[[1, 2]], "Rep3" -> #[[2]], "Mult" -> #[[3]]|> &, links];
  Select[Join[linkEntries, left12, left3], # ["Mult"] =!= 0 &]
];

entryDims3[e_, groups_, repData_] := MapThread[repData[#1]["Reps"][#2]["Dim"] &, {groups, {e["Rep1"], e["Rep2"], e["Rep3"]}}];
entryA3[e_, groups_, repData_] := MapThread[repData[#1]["Reps"][#2]["IndexA"] &, {groups, {e["Rep1"], e["Rep2"], e["Rep3"]}}];

chargedHDim3[entries_List, groups_List, repData_] := Total[(# ["Mult"] Times @@ entryDims3[#, groups, repData]) & /@ entries];

localAnomalyMatrixAndCheck3[entries_List, singlets_, groups_List, branches_List, repData_] := Module[
  {reps, lams, adjs, sums, mixed, coeffRF, coeffFF, mat, rank, quartic, dres, expectedMixed, mixedResiduals, i, j},
  reps = (repData[#]["Reps"] &) /@ groups;
  lams = (repData[#]["Lambda"] &) /@ groups;
  adjs = (# ["adj"] &) /@ reps;

  sums = Table[
    <|
      "IndexA" -> Total[(# ["Mult"] Times @@ Delete[entryDims3[#, groups, repData], i] * entryA3[#, groups, repData][[i]]) & /@ Select[entries, {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]] =!= "r0" &]],
      "QuadC" -> Total[(# ["Mult"] Times @@ Delete[entryDims3[#, groups, repData], i] * reps[[i]][{# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]]]["QuadC"]) & /@ Select[entries, {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]] =!= "r0" &]],
      "QuarticB" -> Total[(# ["Mult"] Times @@ Delete[entryDims3[#, groups, repData], i] * reps[[i]][{# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]]]["QuarticB"]) & /@ Select[entries, {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]] =!= "r0" &]],
      "ExtraD" -> Total[(# ["Mult"] Times @@ Delete[entryDims3[#, groups, repData], i] * reps[[i]][{# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]]]["ExtraD"]) & /@ Select[entries, {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]] =!= "r0" &]]
    |>,
    {i, 3}
  ];

  mixed = Association @ Flatten[
    Table[
      {i, j} -> Total[(# ["Mult"] Times @@ Delete[entryDims3[#, groups, repData], {{j}, {i}}] * entryA3[#, groups, repData][[i]] * entryA3[#, groups, repData][[j]]) & /@ Select[entries, {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[i]] =!= "r0" && {# ["Rep1"], # ["Rep2"], # ["Rep3"]}[[j]] =!= "r0" &]],
      {i, 1, 2}, {j, i + 1, 3}
    ],
    1
  ];

  expectedMixed = Association @ Flatten[
    Table[{i, j} -> Together[etaDot[branches[[i]], branches[[j]]]/(lams[[i]] lams[[j]])], {i, 1, 2}, {j, i + 1, 3}],
    1
  ];
  mixedResiduals = Association @ KeyValueMap[#1 -> Together[#2 - expectedMixed[#1]] &, mixed];

  quartic = Table[Together[adjs[[i]]["QuarticB"] - sums[[i]]["QuarticB"]], {i, 3}];
  dres = Table[Together[adjs[[i]]["ExtraD"] - sums[[i]]["ExtraD"]], {i, 3}];
  coeffRF = Table[1/6 (adjs[[i]]["IndexA"] - sums[[i]]["IndexA"]), {i, 3}];
  coeffFF = Table[2/3 (sums[[i]]["QuadC"] - adjs[[i]]["QuadC"]), {i, 3}];

  mat = ConstantArray[0, {5, 5}];
  mat[[1, 1]] = 1;
  mat[[1, 2]] = mat[[2, 1]] = ($nV - 12)/24;
  mat[[2, 2]] = -($nV + 84)/6;
  Do[
    mat[[1, 2 + i]] = mat[[2 + i, 1]] = coeffRF[[i]]/2;
    mat[[2, 2 + i]] = mat[[2 + i, 2]] = -adjs[[i]]["IndexA"];
    mat[[2 + i, 2 + i]] = coeffFF[[i]],
    {i, 3}
  ];
  Do[
    mat[[2 + i, 2 + j]] = mat[[2 + j, 2 + i]] = 2 mixed[{i, j}],
    {i, 1, 2}, {j, i + 1, 3}
  ];
  mat = Together[mat];
  rank = MatrixRank[mat];

  <|
    "Pass" -> (AllTrue[quartic, # === 0 &] && AllTrue[dres, # === 0 &] && AllTrue[Values[mixedResiduals], # === 0 &] && rank <= 2),
    "Rank" -> rank,
    "Matrix" -> mat,
    "QuarticResiduals" -> quartic,
    "DResiduals" -> dres,
    "Mixed" -> mixed,
    "ExpectedMixed" -> expectedMixed,
    "MixedResiduals" -> mixedResiduals
  |>
];

(* ---------------------------------------------------------------------- *)
(* Canonical keys and readable formatting                                  *)
(* ---------------------------------------------------------------------- *)

entryKeyList3[entries_List] := Sort[({# ["Rep1"], # ["Rep2"], # ["Rep3"], # ["Mult"]} & /@ entries)];

permuteEntry3[e_Association, p_List] := Module[{reps = {e["Rep1"], e["Rep2"], e["Rep3"]}},
  <|"Rep1" -> reps[[p[[1]]]], "Rep2" -> reps[[p[[2]]]], "Rep3" -> reps[[p[[3]]]], "Mult" -> e["Mult"]|>
];

sameGroupPermutations[groups_List] := Select[Permutations[{1, 2, 3}], groups[[#]] === groups &];

solutionKey3[sol_Association] := Module[{groups = sol["Groups"], perms, keyData},
  perms = If[TrueQ[$QuotientIdenticalFactorPermutation], sameGroupPermutations[groups], {{1, 2, 3}}];
  keyData = Table[
    {groups[[p]], sol["Branches"][[p]], sol["Singlets"], entryKeyList3[permuteEntry3[#, p] & /@ sol["Entries"]]},
    {p, perms}
  ];
  ToString[InputForm[First[Sort[keyData]]]]
];

formatRepShort[g_, rep_, repData_] := Module[{r = repData[g]["Reps"][rep]},
  If[rep === "r0", "1", "(" <> StringRiffle[ToString /@ r["Dynkin"], ","] <> ")_" <> ToString[r["Dim"]]]
];

formatEntry3[e_, groups_, repData_] := formatMult[e["Mult"]] <> "(" <>
  StringRiffle[MapThread[formatRepShort[#1, #2, repData] &, {groups, {e["Rep1"], e["Rep2"], e["Rep3"]}}], ","] <> ")";

formatSpectrum3[sol_, repData_] := Module[{terms},
  terms = Join[{formatMult[sol["Singlets"]] <> "(1,1,1)"}, formatEntry3[#, sol["Groups"], repData] & /@ sol["Entries"]];
  StringRiffle[Select[terms, StringLength[#] > 0 &], " + "]
];

(* ---------------------------------------------------------------------- *)
(* Assembly: n = 2 block paired with an n = 1 factor                       *)
(* ---------------------------------------------------------------------- *)

assembleFromN2AndN1[n2sp_Association, n1sp_Association, repData_] := Module[
  {g1, g2, g3, groups, b1, b2, b3, branches, reps1, reps2, reps3, lam1, lam2, lam3,
   target, rem12, rem3, keys12, keys3, edges, edgeData, solutions = {}, recurse},

  g1 = n2sp["Group1"]; g2 = n2sp["Group2"]; g3 = n1sp["Group"];
  groups = {g1, g2, g3};
  b1 = n2sp["Branch1"]; b2 = n2sp["Branch2"]; b3 = n1sp["Branch"];
  branches = {b1, b2, b3};
  reps1 = repData[g1]["Reps"]; reps2 = repData[g2]["Reps"]; reps3 = repData[g3]["Reps"];
  lam1 = repData[g1]["Lambda"]; lam2 = repData[g2]["Lambda"]; lam3 = repData[g3]["Lambda"];

  target = Together[{etaDot[b1, b3]/(lam1 lam3), etaDot[b2, b3]/(lam2 lam3)}];
  If[! vectorNonnegativeQ[target], Return[{}]];

  rem12 = positiveAssoc @ repAssocFromN2Entries[n2sp["Entries"]];
  rem3 = positiveAssoc @ KeyDrop[repAssocFromN1Entries[n1sp["Entries"]], "r0"];
  keys12 = Keys[rem12]; keys3 = Keys[rem3];

  edges = Select[Tuples[{keys12, keys3}],
    Module[{k12 = #[[1]], r3 = #[[2]], a1, a2, a3},
      a1 = reps1[k12[[1]]]["IndexA"]; a2 = reps2[k12[[2]]]["IndexA"]; a3 = reps3[r3]["IndexA"];
      a3 (a1 + a2) > 0
    ] &
  ];

  edgeData = SortBy[
    Map[
      Function[e,
        Module[{k12 = e[[1]], r3n = e[[2]], r1, r2, r3, d1, d2, d3, a1, a2, a3, cvec, step},
          r1 = reps1[k12[[1]]]; r2 = reps2[k12[[2]]]; r3 = reps3[r3n];
          d1 = r1["Dim"]; d2 = r2["Dim"]; d3 = r3["Dim"];
          a1 = r1["IndexA"]; a2 = r2["IndexA"]; a3 = r3["IndexA"];
          cvec = Together[{a1 a3 d2, a2 a3 d1}];
          step = If[productPseudoRealQ[{r1, r2, r3}], 1/2, 1];
          <|"Key12" -> k12, "Rep3" -> r3n, "Dim12" -> d1 d2, "Dim3" -> d3,
            "Contrib" -> cvec, "Step" -> step, "RepData" -> {r1, r2, r3}|>
        ]
      ],
      edges
    ],
    -Total[# ["Contrib"]] &
  ];

  recurse[i_, remTarget_, cur12_, cur3_, links_] := Module[
    {ed, bounds, max, vals, new12, new3, entries, hdim, sing, check, sol},
    If[! vectorNonnegativeQ[remTarget], Return[Null]];
    If[remTarget === {0, 0},
      If[! allowedLeftover12Q[cur12, g1, g2, repData] || ! allowedLeftover1Q[cur3, g3, repData], Return[Null]];
      entries = buildEntriesFromState3[g1, g2, g3, cur12, cur3, links];
      If[! AllTrue[entries, allowedProductMultiplicityQ[# ["Mult"], repDataForKey123[{# ["Rep1"], # ["Rep2"], # ["Rep3"]}, groups, repData]] &], Return[Null]];
      hdim = chargedHDim3[entries, groups, repData];
      sing = Together[$nH - hdim];
      If[sing < 0 || ! IntegerQ[sing], Return[Null]];
      check = localAnomalyMatrixAndCheck3[entries, sing, groups, branches, repData];
      If[! TrueQ[check["Pass"]], Return[Null]];
      sol = <|
        "Groups" -> groups,
        "Branches" -> branches,
        "N2ID" -> Lookup[n2sp, "SpectrumID", Missing["NotAvailable"]],
        "N2Groups" -> {g1, g2},
        "N1ID3" -> n1sp["ID"],
        "Singlets" -> sing,
        "Entries" -> SortBy[entries, {# ["Rep1"] &, # ["Rep2"] &, # ["Rep3"] &, # ["Mult"] &}],
        "LocalCheck" -> check
      |>;
      AppendTo[solutions, sol];
      Return[Null]
    ];
    If[i > Length[edgeData], Return[Null]];
    ed = edgeData[[i]];
    bounds = Join[
      {assocGet[cur12, ed["Key12"], 0]/ed["Dim3"], assocGet[cur3, ed["Rep3"], 0]/ed["Dim12"]},
      Table[If[ed["Contrib"][[k]] > 0, remTarget[[k]]/ed["Contrib"][[k]], Infinity], {k, 2}]
    ];
    max = Min[bounds];
    If[max === Infinity, max = Min[assocGet[cur12, ed["Key12"], 0]/ed["Dim3"], assocGet[cur3, ed["Rep3"], 0]/ed["Dim12"]]];
    vals = ratRange[max, ed["Step"]];
    Scan[
      Function[x,
        If[! allowedTripleMultiplicityQ[x, Sequence @@ ed["RepData"]], Return[Null]];
        new12 = subtractAssoc[cur12, ed["Key12"], ed["Dim3"] x];
        If[new12 === $Failed, Return[Null]];
        new3 = subtractAssoc[cur3, ed["Rep3"], ed["Dim12"] x];
        If[new3 === $Failed, Return[Null]];
        recurse[i + 1, Together[remTarget - x ed["Contrib"]], new12, new3,
          If[x === 0, links, Append[links, {ed["Key12"], ed["Rep3"], x}]]]
      ],
      vals
    ];
  ];

  recurse[1, target, rem12, rem3, {}];
  DeleteDuplicatesBy[solutions, solutionKey3]
];

(* ---------------------------------------------------------------------- *)
(* Output                                                                 *)
(* ---------------------------------------------------------------------- *)

writeTripleOutput[tripleTag_, sols_, repData_] := Module[{txtFile, readable},
  If[! DirectoryQ[$TripleOutDir], CreateDirectory[$TripleOutDir, CreateIntermediateDirectories -> True]];
  txtFile = FileNameJoin[{$TripleOutDir, tripleTag <> ".txt"}];
  readable = If[Length[sols] == 0,
    "No spectra.",
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum3[#1, repData] &, sols], "\n"]
  ];
  Export[txtFile, readable, "Text"];
];

appendCountCSV3[row_Association, csvFile_] := Module[{header, line},
  header = "triple_index,group1,group2,group3,dimG1,dimG2,dimG3,M_drone,count\n";
  If[! FileExistsQ[csvFile], Export[csvFile, header, "Text"]];
  line = StringRiffle[ToString /@ Lookup[row, {"triple_index", "group1", "group2", "group3", "dimG1", "dimG2", "dimG3", "M_drone", "count"}], ","] <> "\n";
  WriteString[csvFile, line]
];

(* ---------------------------------------------------------------------- *)
(* Driver                                                                 *)
(* ---------------------------------------------------------------------- *)

allGroupTriples[groups_List] := Module[{sorted, triples},
  sorted = SortBy[groups, groupSortKey];
  triples = Flatten[Table[{sorted[[i]], sorted[[j]], sorted[[k]]}, {i, Length[sorted]}, {j, i, Length[sorted]}, {k, j, Length[sorted]}], 2];
  If[TrueQ[$ReverseGroupTripleOrder], Reverse[triples], triples]
];

droneCountForGroupList[groupList_List, repData_] := $dimNonRMax - Total[(repData[#]["DimG"] &) /@ groupList];

pruneNegativeDroneTriples[triples_List, repData_] := Module[{kept, deleted},
  If[! TrueQ[$PruneNegativeDroneTriplesAtStart], Return[triples]];
  kept = Select[triples, droneCountForGroupList[#, repData] >= 0 &];
  deleted = Length[triples] - Length[kept];
  If[deleted > 0, Print["Pruned ", deleted, " group triples with negative drone count before scanning."]];
  kept
];

n2CompatibleWithTripleQ[n2sp_, triple_List] := n2sp["Group1"] === triple[[1]] && n2sp["Group2"] === triple[[2]];


validN2SpectrumBlockQ[sp_] := AssociationQ[sp] && KeyExistsQ[sp, "Group1"] && KeyExistsQ[sp, "Group2"] &&
  KeyExistsQ[sp, "Branch1"] && KeyExistsQ[sp, "Branch2"] && KeyExistsQ[sp, "Entries"];

shadowTargets13and23[n2sp_Association, b3_List, groups_List, repData_] := Module[{g1 = groups[[1]], g2 = groups[[2]], g3 = groups[[3]]},
  Together[{etaDot[n2sp["Branch1"], b3]/(repData[g1]["Lambda"] repData[g3]["Lambda"]),
    etaDot[n2sp["Branch2"], b3]/(repData[g2]["Lambda"] repData[g3]["Lambda"])}]
];

scanOneGroupTriple[tripleIndex_, triple_List, n2ByPair_, n1ByGB_, repData_] := Module[
  {g1 = triple[[1]], g2 = triple[[2]], g3 = triple[[3]], dims, mDrone, tripleTag,
   n2Key, n2List, branches3, candidatePairs, activePairs, totalCases, caseCounter = 0,
   printProgressQ, t0, sols = {}, partial, b3, n1List, row},

  dims = (repData[#]["DimG"] &) /@ triple;
  mDrone = $dimNonRMax - Total[dims];
  tripleTag = StringPadLeft[ToString[tripleIndex], 4, "0"] <> "_" <> StringRiffle[triple, "x"];
  Print["\nScanning triple ", tripleIndex, ": ", StringRiffle[triple, " x "], "   M_drone = ", mDrone];

  If[TrueQ[$RequireNonnegativeDroneCount] && mDrone < 0,
    Print["  skipped: negative drone count."];
    writeTripleOutput[tripleTag, {}, repData];
    Return[<|"triple_index" -> tripleIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3,
      "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "M_drone" -> mDrone, "count" -> 0|>]
  ];

  n2Key = {g1, g2};
  n2List = If[KeyExistsQ[n2ByPair, n2Key], n2ByPair[n2Key], {}];
  If[Length[n2List] > 0 && ! AllTrue[n2List, validN2SpectrumBlockQ],
    Print["  ERROR: the n = 2 lookup for ", g1, " x ", g2, " did not return a flat list of spectrum associations."];
    Print["  Internal n2 key = ", n2Key, "; Head[n2List] = ", Head[n2List], "; Head[First[n2List]] = ", Head[First[n2List]]];
    Abort[]
  ];
  If[Length[n2List] == 0 || ! KeyExistsQ[n1ByGB, g3],
    Print["  skipped: missing n = 2 block or n = 1 data."];
    writeTripleOutput[tripleTag, {}, repData];
    Return[<|"triple_index" -> tripleIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3,
      "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "M_drone" -> mDrone, "count" -> 0|>]
  ];

  branches3 = Keys[n1ByGB[g3]];
  Print["  n = 2 spectra for ", g1, " x ", g2, ": ", Length[n2List]];
  Print["  n = 2 branch-pair counts: ", Counts[({#["Branch1"], #["Branch2"]} &) /@ n2List]];
  Print["  branch count for ", g3, ": ", Length[branches3], "   branches = ", branches3];

  candidatePairs = Flatten[
    Table[{n2sp, b3}, {n2sp, n2List}, {b3, branches3}],
    1
  ];
  activePairs = Select[candidatePairs,
    vectorNonnegativeQ[shadowTargets13and23[# [[1]], # [[2]], {g1, g2, g3}, repData]] &
  ];
  Print["  active n2/shadow-branch pairs with nonnegative targets: ", Length[activePairs], " / ", Length[candidatePairs]];
  If[TrueQ[$PrintPairKeyDiagnostics] && Length[candidatePairs] > 0,
    Print["  sample shadow targets {T13,T23}: ",
      Take[(<|"b12" -> {#[[1]]["Branch1"], #[[1]]["Branch2"]}, "b3" -> #[[2]],
          "target" -> shadowTargets13and23[#[[1]], #[[2]], {g1, g2, g3}, repData]|> &) /@ candidatePairs, UpTo[5]]]
  ];

  totalCases = Total[Length[n1ByGB[g3][# [[2]]]] & /@ activePairs];
  Print["  n2/n1 spectrum pairs to scan: ", totalCases];

  printProgressQ[k_Integer] := TrueQ[$PrintTripleScanProgress] && totalCases > 0 && (k == 1 || k == totalCases || Mod[k - 1, $TripleScanProgressEvery] == 0);
  t0 = AbsoluteTime[];

  Do[
    b3 = ap[[2]];
    n1List = n1ByGB[g3][b3];
    Do[
      caseCounter++;
      If[printProgressQ[caseCounter],
        Print["  ", caseCounter, "/", totalCases,
          "   elapsed=", NumberForm[AbsoluteTime[] - t0, {Infinity, 1}], "s",
          "   b12=", {ap[[1]]["Branch1"], ap[[1]]["Branch2"]}, " b3=", b3,
          "   n1 ID3=", n1sp["ID"]]
      ];
      partial = assembleFromN2AndN1[ap[[1]], n1sp, repData];
      If[Length[partial] > 0, sols = Join[sols, partial]];
      ,
      {n1sp, n1List}
    ];
    ,
    {ap, activePairs}
  ];

  sols = DeleteDuplicatesBy[sols, solutionKey3];
  Print["  finished ", StringRiffle[triple, " x "], ": ", Length[sols], " spectra."];
  writeTripleOutput[tripleTag, sols, repData];
  row = <|"triple_index" -> tripleIndex, "group1" -> g1, "group2" -> g2, "group3" -> g3,
    "dimG1" -> dims[[1]], "dimG2" -> dims[[2]], "dimG3" -> dims[[3]], "M_drone" -> mDrone,
    "count" -> Length[sols], "Solutions" -> sols|>;
  row
];

RunN3GTSA[] := Module[
  {repData, n1, n1Good, n2, n2Good, groups, triples, n1ByGB, n2ByPair,
   countsFile, allCounts = {}, allSolutions = {}, row},

  If[! DirectoryQ[$OutDir], CreateDirectory[$OutDir, CreateIntermediateDirectories -> True]];
  If[! DirectoryQ[$TripleOutDir], CreateDirectory[$TripleOutDir, CreateIntermediateDirectories -> True]];
  If[TrueQ[$CleanTripleOutputFolderToTextOnly],
    Quiet[DeleteFile /@ Select[FileNames["*", $TripleOutDir], FileType[#] === File && MemberQ[{"wl", "wxf"}, ToLowerCase[FileExtension[#]]] &]]
  ];

  countsFile = FileNameJoin[{$OutDir, "n3_GTSA_triple_counts.csv"}];
  Quiet[If[FileExistsQ[countsFile], DeleteFile[countsFile]], DeleteFile::fdnfnd];

  Print["Loading representation data from ", $RepInfoFile];
  repData = loadRepData[$RepInfoFile];
  Print["Loaded groups: ", StringRiffle[Keys[repData], ", "]];

  Print["Parsing final n = 1 catalogue from ", $N1CataloguePDF];
  n1 = parseN1Catalogue[$N1CataloguePDF, repData];
  If[IntegerQ[$ExpectedN1SpectrumCount] && Length[n1] =!= $ExpectedN1SpectrumCount,
    Print["Expected ", $ExpectedN1SpectrumCount, " n = 1 spectra, but parsed ", Length[n1], "."];
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n1Good = Select[n1,
    (# ["OneFactorChecks"]["quarticBResidual"] === 0 && # ["OneFactorChecks"]["extraDResidual"] === 0 &&
      # ["OneFactorChecks"]["normActual"] === # ["OneFactorChecks"]["normRequired"]) &
  ];
  If[TrueQ[$RequireIntegralAnomalyVectors], n1Good = Select[n1Good, latticeAdmissibleQ[# ["Branch"]] &]];
  Print["One-factor spectra kept for n = 3 scan after the I_{1,1} lattice test: ", Length[n1Good]];

  Print["Loading n = 2 spectra from ", $N2SpectraWL];
  n2 = loadN2Spectra[$N2SpectraWL];
  If[IntegerQ[$ExpectedN2SpectrumCount] && Length[n2] =!= $ExpectedN2SpectrumCount,
    Print["Expected ", $ExpectedN2SpectrumCount, " n = 2 spectra, but loaded ", Length[n2], "."];
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n2 = MapIndexed[If[KeyExistsQ[#1, "SpectrumID"], #1, Join[#1, <|"SpectrumID" -> #2[[1]]|>]] &, n2];
  If[TrueQ[$CheckN2SourceIDsAgainstN1] && ! TrueQ[validateN2AgainstN1[n2, n1]],
    If[TrueQ[$AbortOnBadInput], Abort[]]
  ];
  n2Good = n2;
  If[TrueQ[$CheckN2InputLocalPass],
    n2Good = Select[n2Good, TrueQ[Lookup[Lookup[#, "LocalCheck", <||>], "Pass", False]] &];
    Print["n = 2 spectra with LocalCheck[Pass] kept: ", Length[n2Good]];
    If[Length[n2Good] < Length[n2] && TrueQ[$AbortOnBadInput],
      Print["Some n = 2 spectra failed/missed LocalCheck[Pass]. Set $AbortOnBadInput=False to continue."];
      Abort[]
    ];
  ];
  If[TrueQ[$CheckN2BranchLattice],
    Module[{badN2Lattice = Select[n2Good, ! n2BranchesLatticeAdmissibleQ[#] &]},
      If[Length[badN2Lattice] > 0,
        Print["Found ", Length[badN2Lattice], " n = 2 spectra with branch vectors outside the displayed I_{1,1} lattice."];
        Print["First bad branch pairs: ", Take[({#["Branch1"], #["Branch2"]} &) /@ badN2Lattice, UpTo[10]]];
        If[TrueQ[$AbortOnBadInput], Abort[], n2Good = Complement[n2Good, badN2Lattice]]
      ];
    ]
  ];

  groups = SortBy[Union[Keys[GroupBy[n1Good, # ["Group"] &]], Flatten[({# ["Group1"], # ["Group2"]} &) /@ n2Good]], groupSortKey];
  triples = allGroupTriples[groups];
  Print["Raw gauge-group triples before drone pruning: ", Length[triples]];
  triples = pruneNegativeDroneTriples[triples, repData];
  Print["Gauge-group triples to scan: ", Length[triples]];

  n1ByGB = GroupBy[n1Good, {# ["Group"] &, # ["Branch"] &}];
  (* Important: this is a single key {Group1,Group2}, not nested GroupBy. *)
  n2ByPair = GroupBy[n2Good, {# ["Group1"], # ["Group2"]} &];
  (* IMPORTANT: list-valued pair keys must be read by assoc[key], not by Lookup[assoc,key,...], because Lookup treats a list key as a list of separate keys. *)
  If[TrueQ[$PrintPairKeyDiagnostics],
    Print["n = 2 pair keys loaded: ", Length[Keys[n2ByPair]]];
    If[KeyExistsQ[n2ByPair, {"A3", "A3"}],
      Print["Diagnostic A3 x A3 n = 2 spectra: ", Length[n2ByPair[{"A3", "A3"}]],
        "; branch-pair counts: ", Counts[({#["Branch1"], #["Branch2"]} &) /@ n2ByPair[{"A3", "A3"}]]]
    ];
  ];

  Do[
    row = scanOneGroupTriple[i, triples[[i]], n2ByPair, n1ByGB, repData];
    AppendTo[allCounts, KeyDrop[row, "Solutions"]];
    allSolutions = DeleteDuplicatesBy[Join[allSolutions, Lookup[row, "Solutions", {}]], solutionKey3];
    Print["  triple summary: ", StringRiffle[triples[[i]], " x "],
      " has ", row["count"], " spectra; total so far = ", Length[allSolutions], "."];
    appendCountCSV3[KeyDrop[row, "Solutions"], countsFile];
    Export[FileNameJoin[{$OutDir, "n3_GTSA_all_spectra_so_far.wxf"}], allSolutions, "WXF"];
    Put[allSolutions, FileNameJoin[{$OutDir, "n3_GTSA_all_spectra_so_far.wl"}]];
    ,
    {i, Length[triples]}
  ];

  allSolutions = DeleteDuplicatesBy[allSolutions, solutionKey3];
  Export[FileNameJoin[{$OutDir, "n3_GTSA_all_spectra.wxf"}], allSolutions, "WXF"];
  Put[allSolutions, FileNameJoin[{$OutDir, "n3_GTSA_all_spectra.wl"}]];
  Export[FileNameJoin[{$OutDir, "n3_GTSA_all_spectra_readable.txt"}],
    StringRiffle[MapIndexed["Spectrum " <> ToString[#2[[1]]] <> ". " <> formatSpectrum3[#1, repData] &, allSolutions], "\n"],
    "Text"
  ];
  Export[FileNameJoin[{$OutDir, "n3_GTSA_triple_counts_final.csv"}], Normal /@ allCounts];

  If[TrueQ[$DeleteTemporaryFilesAfterFullScan],
    Quiet[DeleteFile /@ Select[{
      FileNameJoin[{$OutDir, "n3_GTSA_all_spectra_so_far.wl"}],
      FileNameJoin[{$OutDir, "n3_GTSA_all_spectra_so_far.wxf"}],
      countsFile
    }, FileExistsQ]];
    Print["Temporary checkpoint files deleted after successful full scan."]
  ];

  Print["\nFull n = 3 scan finished. Total spectra: ", Length[allSolutions]];
  <|"Counts" -> allCounts, "Solutions" -> allSolutions, "RepData" -> repData|>
];

If[TrueQ[$RunNow], RunN3GTSA[]];
